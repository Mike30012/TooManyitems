# Classic TooManyItems – NeoForge 1.21.1

A clean-room starter project inspired by the visual layout in the supplied screenshot.

## Target
- Minecraft 1.21.1
- NeoForge 21.1.235
- Java 21
- Gradle / ModDevGradle

## Current prototype
- Press **O** to open the menu.
- Classic grey inventory-style panel with armor slots, player preview, 2x2 crafting area, 27 inventory slots and 9 hotbar slots.
- Seven save-slot buttons on the left.
- Search field and eight-column item browser on the right.
- Clicking an item attempts to add a stack of 64 to the player's inventory.

## Important status
This is a starter implementation, not a finished port. The supplied 2014 archive contains compiled `.class` files and an image, but no Java source. The old class files have not been converted into a modern working implementation.

The save buttons currently select a slot; persistent save/load, creative-mode restrictions, categories/tabs, pagination, item-stack settings and pixel-accurate skinning still need implementation. The GUI is a visual recreation of the supplied reference, not a pixel-perfect port. Crafting slots and inventory slots are currently decorative; item browser selection is functional. The player preview and layout must be tested in the actual 1.21.1 client.

## Build
Install a Java 21 JDK, then run:

```bash
./gradlew build
```

On Windows:

```bat
gradlew.bat build
```

The resulting mod JAR will be in `build/libs/`.
