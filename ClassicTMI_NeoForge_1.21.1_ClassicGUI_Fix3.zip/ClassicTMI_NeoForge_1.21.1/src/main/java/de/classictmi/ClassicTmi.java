package de.classictmi;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

@Mod(ClassicTmi.MOD_ID)
public final class ClassicTmi {
    public static final String MOD_ID = "classic_tmi";
    public static KeyMapping OPEN_MENU;

    public ClassicTmi() {
        // Event handlers are registered by the @EventBusSubscriber classes below.
    }

    @EventBusSubscriber(modid = MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ClientModEvents {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            OPEN_MENU = new KeyMapping(
                "key.classic_tmi.open",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "key.categories.classic_tmi"
            );
            event.register(OPEN_MENU);
        }
    }

    @EventBusSubscriber(modid = MOD_ID, value = Dist.CLIENT)
    public static final class ClientEvents {
        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            if (OPEN_MENU == null || !OPEN_MENU.consumeClick()) {
                return;
            }

            Minecraft minecraft = Minecraft.getInstance();

            // Deliberately do not require screen == null:
            // O must also replace the vanilla player inventory screen.
            if (!(minecraft.screen instanceof ClassicTmiScreen)) {
                minecraft.setScreen(new ClassicTmiScreen());
            }
        }
    }
}
