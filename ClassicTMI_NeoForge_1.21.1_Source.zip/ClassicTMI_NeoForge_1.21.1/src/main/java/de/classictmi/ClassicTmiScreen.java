package de.classictmi;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClassicTmiScreen extends Screen {
    private static final int SLOT = 18;
    private static final int COLS = 8;
    private final List<Item> visibleItems = new ArrayList<>();
    private final List<ItemStack>[] saved = new List[7];
    private EditBox search;
    private int selectedSave = 0;
    private int gridX, gridY, gridW, gridH;
    private int scroll;

    public ClassicTmiScreen() {
        super(Component.literal("TooManyItems"));
        for (int i = 0; i < saved.length; i++) saved[i] = new ArrayList<>();
        rebuildItems();
    }

    private void rebuildItems() {
        visibleItems.clear();
        String query = search == null ? "" : search.getValue().toLowerCase(Locale.ROOT);
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == net.minecraft.world.item.Items.AIR) continue;
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getName(new ItemStack(item)).getString().toLowerCase(Locale.ROOT);
            if (query.isBlank() || id.contains(query) || name.contains(query)) visibleItems.add(item);
        }
    }

    @Override
    protected void init() {
        int leftW = 104;
        int rightW = Math.min(176, Math.max(150, width / 4));
        int centerW = Math.min(330, width - leftW - rightW - 24);
        int total = leftW + centerW + rightW + 16;
        int startX = Math.max(4, (width - total) / 2);
        int top = Math.max(28, (height - 220) / 2);

        for (int i = 0; i < 7; i++) {
            final int index = i;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                Component.literal("Save " + (i + 1)),
                b -> { selectedSave = index; }
            ).bounds(startX, top + i * 31, leftW - 4, 27).build());
        }

        gridX = startX + leftW + centerW + 10;
        gridY = top + 40;
        gridW = rightW;
        gridH = Math.max(100, Math.min(260, height - gridY - 28));

        search = new EditBox(font, gridX, top, gridW - 2, 24, Component.literal("Search"));
        search.setHint(Component.literal("Search"));
        search.setResponder(s -> { scroll = 0; rebuildItems(); });
        addRenderableWidget(search);
        rebuildItems();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        int left = Math.max(4, (width - (104 + Math.min(330, width - 290) + 186)) / 2);
        int top = Math.max(28, (height - 220) / 2);
        int centerX = left + 110;
        int centerW = Math.min(330, width - 290);
        int panelY = top + 34;

        // Classic grey inventory window
        g.fill(centerX, panelY, centerX + centerW, panelY + 220, 0xFF555555);
        g.fill(centerX + 2, panelY + 2, centerX + centerW - 2, panelY + 218, 0xFFD0D0D0);
        g.drawString(font, "Handwerk", centerX + centerW - 112, panelY + 10, 0xFF404040, false);

        // Player inventory-style slots
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) drawSlot(g, centerX + 10 + col * 18, panelY + 116 + row * 36);
        }
        for (int col = 0; col < 9; col++) drawSlot(g, centerX + 10 + col * 18, panelY + 224);

        // Search results on the right
        g.fill(gridX - 3, gridY + 28, gridX + gridW, gridY + gridH + 30, 0xAA111111);
        int rows = Math.max(1, (gridH - 8) / SLOT);
        int max = rows * COLS;
        for (int i = 0; i < Math.min(max, visibleItems.size() - scroll); i++) {
            int x = gridX + 4 + (i % COLS) * SLOT;
            int y = gridY + 34 + (i / COLS) * SLOT;
            Item item = visibleItems.get(i + scroll);
            g.renderItem(new ItemStack(item), x, y);
            if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
                g.renderTooltip(font, new ItemStack(item), mouseX, mouseY);
            }
        }

        // Saved-item strip in the lower middle area
        g.drawString(font, "Save slot " + (selectedSave + 1) + "  (" + saved[selectedSave].size() + " items)",
            centerX + 10, panelY + 94, 0xFF404040, false);
        for (int i = 0; i < Math.min(9, saved[selectedSave].size()); i++) {
            int x = centerX + 10 + i * 18;
            int y = panelY + 80;
            g.renderItem(saved[selectedSave].get(i), x, y);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawSlot(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF777777);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFFB8B8B8);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        int itemStartX = gridX + 4;
        int itemStartY = gridY + 34;
        int col = (int)(mouseX - itemStartX) / SLOT;
        int row = (int)(mouseY - itemStartY) / SLOT;
        int rows = Math.max(1, (gridH - 8) / SLOT);
        int index = scroll + row * COLS + col;
        if (button == 0 && col >= 0 && col < COLS && row >= 0 && row < rows
                && mouseX >= itemStartX && mouseY >= itemStartY
                && index >= 0 && index < visibleItems.size()) {
            ItemStack stack = new ItemStack(visibleItems.get(index), 64);
            if (Minecraft.getInstance().player != null) {
                Minecraft.getInstance().player.getInventory().add(stack);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        scroll = Math.max(0, Math.min(Math.max(0, visibleItems.size() - 1), scroll - (int)Math.signum(deltaY) * COLS));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
