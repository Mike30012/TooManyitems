# Classic TooManyItems – NeoForge 1.21.1

A clean-room starter project inspired by the visual layout in the supplied screenshot.

## Target
- Minecraft 1.21.1
- NeoForge 21.1.235
- Java 21
- Gradle / ModDevGradle

## Current prototype
- Press **O** to open the menu.
- Classic grey inventory-style panel with armor slots, player preview, 2x2 crafting area, 27 inventory slots and 9 hotbar slots.
- Seven save-slot buttons on the left.
- Search field and eight-column item browser on the right.
- Clicking an item attempts to add a stack of 64 to the player's inventory.

## Important status
This is a starter implementation, not a finished port. The supplied 2014 archive contains compiled `.class` files and an image, but no Java source. The old class files have not been converted into a modern working implementation.

The save buttons currently select a slot; persistent save/load, creative-mode restrictions, categories/tabs, pagination, item-stack settings and pixel-accurate skinning still need implementation. The GUI is a visual recreation of the supplied reference, not a pixel-perfect port. Crafting slots and inventory slots are currently decorative; item browser selection is functional. The player preview and layout must be tested in the actual 1.21.1 client.

## Build
Install a Java 21 JDK, then run:

```bash
./gradlew build
```

On Windows:

```bat
gradlew.bat build
```

The resulting mod JAR will be in `build/libs/`.


### Latest GUI behavior
- Press **O** to open the TooManyItems screen, including while the vanilla inventory is open.
- The game world behind the GUI is no longer blurred; a light dark overlay is used instead.
- Minecraft item icons retain their original pixel-art texture by design.


## Multi-version compatibility status

This archive is the **1.21.1 baseline**. It is not yet a universal JAR and it
does not claim that the same Java sources compile on later Minecraft versions.

Planned target: keep Classic TMI updated from 1.21.1 through the newest stable
Minecraft Java Edition release, using NeoForge builds for each supported
Minecraft line. Each new line must be ported and compiled against its own
NeoForge/Minecraft APIs before it is marked supported.

Current baseline:
- Minecraft 1.21.1
- NeoForge 21.1.235
- Java 21

Latest stable target checked on 2026-11-23:
- Minecraft Java 26.3
- NeoForge 26.3.0.102 was listed as a release build in the current version
  listings; the exact newest loader build should be rechecked when building.
- Java 25 is required for the 26.x line.

**26.3 is a porting target, not a working build in this archive yet.**
The existing GUI uses 1.21.1 APIs and must be adapted and tested for 26.3.
The workflow in `.github/workflows/build.yml` currently builds only the
verified target line configured by this project (1.21.1).
