package de.classictmi;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

@Mod(ClassicTmi.MOD_ID)
public final class ClassicTmi {
    public static final String MOD_ID = "classic_tmi";
    public static KeyMapping OPEN_MENU;

    public ClassicTmi() {
        // Client key mapping and tick handlers are registered by the subscribers below.
    }

    @EventBusSubscriber(modid = MOD_ID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ClientModEvents {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            OPEN_MENU = new KeyMapping(
                "key.classic_tmi.open",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "key.categories.classic_tmi"
            );
            event.register(OPEN_MENU);
        }
    }

    @EventBusSubscriber(modid = MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
    public static final class ClientEvents {
        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            if (OPEN_MENU == null || !OPEN_MENU.consumeClick()) {
                return;
            }

            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player == null) {
                return;
            }

            // Toggle from any in-game screen: O opens the TMI-wrapped real inventory;
            // pressing O again returns to the ordinary vanilla inventory.
            if (minecraft.screen instanceof ClassicTmiInventoryScreen) {
                minecraft.setScreen(new net.minecraft.client.gui.screens.inventory.InventoryScreen(minecraft.player));
            } else {
                minecraft.setScreen(new ClassicTmiInventoryScreen(minecraft.player));
            }
        }
    }
}
