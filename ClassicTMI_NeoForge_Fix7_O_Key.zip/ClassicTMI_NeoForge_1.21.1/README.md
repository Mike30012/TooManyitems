# Classic TooManyItems – NeoForge 1.21.1

A clean-room starter project inspired by the visual layout in the supplied screenshot.

## Target
- Minecraft 1.21.1
- NeoForge 21.1.235
- Java 21
- Gradle / ModDevGradle

## Current prototype
- Press **O** to open the menu.
- Classic grey inventory-style panel with armor slots, player preview, 2x2 crafting area, 27 inventory slots and 9 hotbar slots.
- Seven save-slot buttons on the left.
- Search field and eight-column item browser on the right.
- Clicking an item attempts to add a stack of 64 to the player's inventory.

## Important status
This is a starter implementation, not a finished port. The supplied 2014 archive contains compiled `.class` files and an image, but no Java source. The old class files have not been converted into a modern working implementation.

The save buttons currently select a slot; persistent save/load, creative-mode restrictions, categories/tabs, pagination, item-stack settings and pixel-accurate skinning still need implementation. The GUI is a visual recreation of the supplied reference, not a pixel-perfect port. Crafting slots and inventory slots are currently decorative; item browser selection is functional. The player preview and layout must be tested in the actual 1.21.1 client.

## Build
Install a Java 21 JDK, then run:

```bash
./gradlew build
```

On Windows:

```bat
gradlew.bat build
```

The resulting mod JAR will be in `build/libs/`.


### Latest GUI behavior
- Press **O** to open the TooManyItems screen, including while the vanilla inventory is open.
- The game world behind the GUI is no longer blurred; a light dark overlay is used instead.
- Minecraft item icons retain their original pixel-art texture by design.


## Fix7 – O-Key subscriber adjustment

This revision moves the client key-registration and client-tick subscribers
from nested classes into separate top-level subscriber classes. The O key
mapping is registered on the MOD bus and consumed on the GAME bus. Pressing
O while in a world opens the TMI-wrapped vanilla inventory; pressing O again
returns to the vanilla inventory.

The side panels are still a work in progress and are not yet a pixel-perfect
recreation of the supplied 2013 screenshot. This archive has not been
compiled or tested in a running Minecraft client in this environment.
If O still does nothing, check Options > Controls > Key Binds for a conflict
on the "Open TooManyItems" binding and share the GitHub Actions log.
