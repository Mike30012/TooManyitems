package de.classictmi;

import net.neoforged.fml.common.Mod;

@Mod(ClassicTmi.MOD_ID)
public final class ClassicTmi {
    public static final String MOD_ID = "classic_tmi";

    public ClassicTmi() {
        // Client key mapping and input handling are registered by the
        // top-level @EventBusSubscriber classes.
    }
}
