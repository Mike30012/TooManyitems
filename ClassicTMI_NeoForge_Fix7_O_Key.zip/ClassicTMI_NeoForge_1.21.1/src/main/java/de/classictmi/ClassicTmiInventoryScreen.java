package de.classictmi;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * TMI side panels drawn around the real vanilla inventory.
 * The center screen, container slots, armor slots and crafting grid are inherited
 * from InventoryScreen and remain the actual Minecraft inventory.
 */
public class ClassicTmiInventoryScreen extends InventoryScreen {
    private static final int SLOT = 18;
    private static final int COLS = 7;
    private final List<Item> items = new ArrayList<>();
    private EditBox search;
    private int scroll;
    private int selectedSave;
    private int leftX, rightX, panelY, panelH, rightW;

    public ClassicTmiInventoryScreen(Player player) {
        super(player);
        rebuildItems();
    }

    private void rebuildItems() {
        items.clear();
        String query = search == null ? "" : search.getValue().toLowerCase(Locale.ROOT);
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == net.minecraft.world.item.Items.AIR) continue;
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getName(new ItemStack(item)).getString().toLowerCase(Locale.ROOT);
            if (query.isBlank() || id.contains(query) || name.contains(query)) items.add(item);
        }
    }

    @Override
    protected void init() {
        super.init();
        panelY = Math.max(34, (height - 230) / 2);
        panelH = Math.min(230, height - panelY - 12);
        leftX = 6;
        rightW = Math.min(150, Math.max(126, width / 8));
        rightX = width - rightW - 6;

        for (int i = 0; i < 7; i++) {
            final int slot = i;
            addRenderableWidget(Button.builder(Component.literal("Save " + (i + 1)),
                    b -> selectedSave = slot)
                .bounds(leftX, panelY + 8 + i * 30, 76, 24).build());
        }

        search = new EditBox(font, rightX + 4, panelY + 7, rightW - 8, 18, Component.literal("Search"));
        search.setMaxLength(80);
        search.setHint(Component.literal("Search items"));
        search.setResponder(s -> { scroll = 0; rebuildItems(); });
        addRenderableWidget(search);
        rebuildItems();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Keep the classic unblurred world backdrop.
        g.fill(0, 0, width, height, 0x55000000);
        super.render(g, mouseX, mouseY, partialTick);

        drawPanel(g, leftX - 2, panelY, 82, panelH);
        g.drawString(font, "TooManyItems", leftX + 2, panelY - 11, 0xFFFFFFFF, false);
        g.drawString(font, "Save " + (selectedSave + 1), leftX + 4, panelY + panelH - 15, 0xFF333333, false);

        drawPanel(g, rightX, panelY, rightW, panelH);
        g.drawString(font, "Items", rightX + 5, panelY - 11, 0xFFFFFFFF, false);
        int gridTop = panelY + 31;
        int gridBottom = panelY + panelH - 5;
        int rows = Math.max(1, (gridBottom - gridTop) / SLOT);
        int max = rows * COLS;
        int count = Math.min(max, Math.max(0, items.size() - scroll));
        for (int i = 0; i < count; i++) {
            int col = i % COLS;
            int row = i / COLS;
            int x = rightX + 5 + col * SLOT;
            int y = gridTop + row * SLOT;
            ItemStack stack = new ItemStack(items.get(scroll + i));
            g.renderItem(stack, x, y);
            if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
                g.renderTooltip(font, stack, mouseX, mouseY);
            }
        }
        g.drawString(font, "O: TMI  |  E: Inventar", rightX + 4, panelY + panelH - 13, 0xFF555555, false);
    }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF303030);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFFE0E0E0);
        g.fill(x + 4, y + 4, x + w - 4, y + h - 4, 0xFFC6C6C6);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;

        int gridTop = panelY + 31;
        int col = (int) (mouseX - (rightX + 5)) / SLOT;
        int row = (int) (mouseY - gridTop) / SLOT;
        int rows = Math.max(1, (panelH - 36) / SLOT);
        int index = scroll + row * COLS + col;
        if (button == 0 && mouseX >= rightX + 5 && mouseY >= gridTop &&
                col >= 0 && col < COLS && row >= 0 && row < rows &&
                index >= 0 && index < items.size()) {
            Player player = Minecraft.getInstance().player;
            if (player != null) player.getInventory().add(new ItemStack(items.get(index), 64));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (mouseX >= rightX && mouseX <= rightX + rightW) {
            scroll = Math.max(0, Math.min(Math.max(0, items.size() - 1),
                    scroll - (int) Math.signum(deltaY) * COLS));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
