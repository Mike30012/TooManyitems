package de.classictmi;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClassicTmiScreen extends Screen {
    private static final int SLOT = 18;
    private static final int ITEM_COLS = 8;

    private final List<Item> visibleItems = new ArrayList<>();
    private final List<ItemStack>[] saved = new List[7];

    private EditBox search;
    private int selectedSave;
    private int scroll;
    private int leftX, topY, centerX, centerY, rightX, rightY;
    private int panelW, panelH, rightW, rightH;

    public ClassicTmiScreen() {
        super(Component.literal("TooManyItems"));
        for (int i = 0; i < saved.length; i++) saved[i] = new ArrayList<>();
        rebuildItems();
    }

    private void rebuildItems() {
        visibleItems.clear();
        String query = search == null ? "" : search.getValue().toLowerCase(Locale.ROOT);
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == net.minecraft.world.item.Items.AIR) continue;
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getName(new ItemStack(item)).getString().toLowerCase(Locale.ROOT);
            if (query.isBlank() || id.contains(query) || name.contains(query)) visibleItems.add(item);
        }
    }

    @Override
    protected void init() {
        leftX = 4;
        topY = 28;
        panelW = Math.min(330, Math.max(290, width / 3));
        panelH = 244;
        rightW = Math.min(166, Math.max(140, width / 5));
        rightH = Math.min(390, height - 76);

        int wholeW = 104 + 12 + panelW + 12 + rightW;
        int start = Math.max(4, (width - wholeW) / 2);
        leftX = Math.max(4, start - 4);
        centerX = start + 104 + 8;
        centerY = Math.max(36, (height - panelH) / 2);
        rightX = centerX + panelW + 12;
        rightY = topY + 28;

        for (int i = 0; i < 7; i++) {
            final int index = i;
            addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                Component.literal("Save " + (i + 1)),
                b -> selectedSave = index
            ).bounds(leftX, topY + i * 31, 96, 27).build());
        }

        search = new EditBox(font, rightX, topY, rightW - 22, 22, Component.literal("Search"));
        search.setHint(Component.literal("Search"));
        search.setMaxLength(80);
        search.setResponder(s -> {
            scroll = 0;
            rebuildItems();
        });
        addRenderableWidget(search);
        rebuildItems();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Keep the world sharp: Screen.renderBackground() applies the modern menu blur.
        // The original TooManyItems screen showed the world behind its panels without blur.
        g.fill(0, 0, width, height, 0x55000000);

        // Classic top category strip
        String[] tabs = {"T", "S", "C", "A", "◆", "☼", "✦", "☾", "☘", "♥"};
        int tabX = 5;
        for (int i = 0; i < tabs.length; i++) {
            int x = tabX + i * 25;
            g.fill(x, 5, x + 22, 27, 0xFF202B38);
            g.fill(x + 2, 7, x + 20, 25, 0xFF68798B);
            g.drawCenteredString(font, tabs[i], x + 11, 11, 0xFFFFFFFF);
        }

        // Right-side category icons and page indicator
        String[] categories = {"✦", "◆", "♜", "♟", "♫"};
        int cx = rightX;
        for (int i = 0; i < categories.length; i++) {
            g.drawCenteredString(font, categories[i], cx + 8 + i * 25, 32, 0xFFFFD45A);
        }
        g.drawString(font, "1/1", rightX + rightW - 20, 28, 0xFFBBBBBB, false);

        // Main inventory panel: raised light-grey frame
        drawPanel(g, centerX, centerY, panelW, panelH);
        int innerX = centerX + 8;
        int innerY = centerY + 8;

        // Player armor slots and preview area
        for (int i = 0; i < 4; i++) {
            drawSlot(g, innerX, innerY + i * 26);
            String armor = switch (i) { case 0 -> "♢"; case 1 -> "♧"; case 2 -> "♙"; default -> "♧"; };
            g.drawCenteredString(font, armor, innerX + 9, innerY + 5 + i * 26, 0xFF4C8DCE);
        }

        int previewX = innerX + 24;
        int previewY = innerY;
        g.fill(previewX, previewY, previewX + 78, previewY + 104, 0xFF101010);
        Player player = Minecraft.getInstance().player;
        if (player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(
                g, previewX + 4, previewY + 4, previewX + 74, previewY + 100,
                42, 0.0F, (float) mouseX, (float) mouseY, player
            );
        }

        // Crafting 2x2 and output slot
        int craftX = centerX + panelW - 112;
        int craftY = centerY + 30;
        g.drawString(font, "Handwerk", craftX - 2, centerY + 12, 0xFF404040, false);
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) drawSlot(g, craftX + col * 27, craftY + row * 27);
        }
        g.drawString(font, "➜", craftX + 57, craftY + 20, 0xFF777777, false);
        drawSlot(g, craftX + 84, craftY + 14);

        // Main 27 inventory slots
        int invX = centerX + 8;
        int invY = centerY + 116;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) drawSlot(g, invX + col * 18, invY + row * 26);
        }

        // Hotbar
        int hotY = centerY + 196;
        for (int col = 0; col < 9; col++) drawSlot(g, invX + col * 18, hotY);

        // Saved slot indicator (save buttons select one of seven lists)
        g.drawString(font, "Save " + (selectedSave + 1), centerX + 10, centerY + panelH - 17, 0xFF555555, false);

        // Search box and item catalogue on the right
        g.fill(rightX - 3, rightY + 24, rightX + rightW, rightY + rightH, 0xAA090909);
        int rows = Math.max(1, (rightH - 32) / SLOT);
        int max = rows * ITEM_COLS;
        for (int i = 0; i < Math.min(max, visibleItems.size() - scroll); i++) {
            int x = rightX + 3 + (i % ITEM_COLS) * SLOT;
            int y = rightY + 30 + (i / ITEM_COLS) * SLOT;
            Item item = visibleItems.get(i + scroll);
            g.renderItem(new ItemStack(item), x, y);
            if (mouseX >= x && mouseX < x + 16 && mouseY >= y && mouseY < y + 16) {
                g.renderTooltip(font, new ItemStack(item), mouseX, mouseY);
            }
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawPanel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF404040);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, 0xFFF0F0F0);
        g.fill(x + 4, y + 4, x + w - 4, y + h - 4, 0xFFD0D0D0);
    }

    private void drawSlot(GuiGraphics g, int x, int y) {
        g.fill(x, y, x + 18, y + 18, 0xFF555555);
        g.fill(x + 1, y + 1, x + 17, y + 17, 0xFF8B8B8B);
        g.fill(x + 2, y + 2, x + 16, y + 16, 0xFFB8B8B8);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;

        int startX = rightX + 3;
        int startY = rightY + 30;
        int col = (int) (mouseX - startX) / SLOT;
        int row = (int) (mouseY - startY) / SLOT;
        int rows = Math.max(1, (rightH - 32) / SLOT);
        int index = scroll + row * ITEM_COLS + col;

        if (button == 0 && mouseX >= startX && mouseY >= startY &&
            col >= 0 && col < ITEM_COLS && row >= 0 && row < rows &&
            index >= 0 && index < visibleItems.size()) {
            ItemStack stack = new ItemStack(visibleItems.get(index), 64);
            if (Minecraft.getInstance().player != null) {
                Minecraft.getInstance().player.getInventory().add(stack);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        scroll = Math.max(0, Math.min(Math.max(0, visibleItems.size() - 1),
            scroll - (int) Math.signum(deltaY) * ITEM_COLS));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
