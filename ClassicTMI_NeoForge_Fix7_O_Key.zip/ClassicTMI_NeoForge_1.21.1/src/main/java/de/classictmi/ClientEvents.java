package de.classictmi;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(
    modid = ClassicTmi.MOD_ID,
    bus = EventBusSubscriber.Bus.GAME,
    value = Dist.CLIENT
)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        while (ClientModEvents.OPEN_MENU.consumeClick()) {
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player == null) {
                continue;
            }

            if (minecraft.screen instanceof ClassicTmiInventoryScreen) {
                minecraft.setScreen(new InventoryScreen(minecraft.player));
            } else {
                minecraft.setScreen(new ClassicTmiInventoryScreen(minecraft.player));
            }
        }
    }
}
