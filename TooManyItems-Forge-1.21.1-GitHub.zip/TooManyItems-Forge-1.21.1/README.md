# TooManyItems – Forge 1.21.1

This is a GitHub-ready Forge project targeting Minecraft **1.21.1** and Java **21**.

## Build on GitHub

1. Create an empty GitHub repository.
2. Upload the contents of this folder (the files inside it, not the outer ZIP).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build TooManyItems** with **Run workflow**, or push a commit.
5. Open the completed workflow run and download the `TooManyItems-Forge-1.21.1` artifact.

The workflow runs `gradle build` and uploads the resulting JAR from `build/libs/`.

## Current implementation

- Press **O** in-game to open the item browser.
- Search by item name or registry ID.
- Scroll through the item list.
- In Creative mode, click an item to add a stack of 64 to the inventory.
- Press **Esc** to close.

## About the supplied 1.6.4 archive

The original upload contains compiled `.class` files, not Java source. Those legacy files are kept in `legacy-1.6.4/` for reference. They cannot be dropped into a 1.21.1 mod unchanged; Minecraft/Forge APIs and mod loading changed substantially. This project is therefore a clean, working-start-point recreation, not a byte-for-byte port of every old panel and feature yet.

## Local build (optional)

Install a Java 21 JDK, then run:

```bash
gradle build
```

The output is in `build/libs/`.
