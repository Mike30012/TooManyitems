package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ItemBrowserScreen extends Screen {
    private static final int COLUMNS = 9;
    private static final int SLOT_SIZE = 20;
    private final List<Item> allItems = new ArrayList<>();
    private final List<Item> visibleItems = new ArrayList<>();
    private EditBox search;
    private int scroll;

    public ItemBrowserScreen() {
        super(Component.literal("TooManyItems"));
        BuiltInRegistries.ITEM.stream()
                .filter(item -> item != Items.AIR)
                .forEach(allItems::add);
        allItems.sort((a, b) -> BuiltInRegistries.ITEM.getKey(a).toString()
                .compareToIgnoreCase(BuiltInRegistries.ITEM.getKey(b).toString()));
        filterItems();
    }

    @Override
    protected void init() {
        int panelWidth = COLUMNS * SLOT_SIZE + 20;
        int left = (width - panelWidth) / 2;
        search = new EditBox(font, left + 10, height / 2 - 112, panelWidth - 20, 18,
                Component.literal("Search items"));
        search.setHint(Component.literal("Search items..."));
        search.setResponder(value -> {
            scroll = 0;
            filterItems();
        });
        addRenderableWidget(search);
        setInitialFocus(search);
    }

    private void filterItems() {
        String query = search == null ? "" : search.getValue().toLowerCase(Locale.ROOT);
        visibleItems.clear();
        for (Item item : allItems) {
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getDescription().getString().toLowerCase(Locale.ROOT);
            if (query.isBlank() || id.contains(query) || name.contains(query)) {
                visibleItems.add(item);
            }
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        int panelWidth = COLUMNS * SLOT_SIZE + 20;
        int panelHeight = 174;
        int left = (width - panelWidth) / 2;
        int top = height / 2 - 125;
        graphics.fill(left, top, left + panelWidth, top + panelHeight, 0xE0101018);
        graphics.renderOutline(left, top, panelWidth, panelHeight, 0xFF777777);
        graphics.drawCenteredString(font, "TooManyItems", width / 2, top + 7, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);

        int gridX = left + 10;
        int gridY = top + 43;
        int rows = 6;
        int start = scroll * COLUMNS;
        for (int slot = 0; slot < COLUMNS * rows; slot++) {
            int x = gridX + (slot % COLUMNS) * SLOT_SIZE;
            int y = gridY + (slot / COLUMNS) * SLOT_SIZE;
            graphics.fill(x, y, x + 18, y + 18, 0x80505050);
            int index = start + slot;
            if (index < visibleItems.size()) {
                Item item = visibleItems.get(index);
                ItemStack stack = new ItemStack(item);
                graphics.renderItem(stack, x + 1, y + 1);
                if (mouseX >= x && mouseX < x + 18 && mouseY >= y && mouseY < y + 18) {
                    graphics.renderTooltip(font, stack, mouseX, mouseY);
                }
            }
        }
        int pageCount = Math.max(1, (visibleItems.size() + COLUMNS * rows - 1) / (COLUMNS * rows));
        graphics.drawCenteredString(font,
                (scroll + 1) + " / " + pageCount + "   (" + visibleItems.size() + " items)",
                width / 2, top + 165, 0xCCCCCC);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button != 0 || minecraft == null || minecraft.player == null) return false;

        int panelWidth = COLUMNS * SLOT_SIZE + 20;
        int left = (width - panelWidth) / 2;
        int top = height / 2 - 125;
        int gridX = left + 10;
        int gridY = top + 43;
        int col = (int) ((mouseX - gridX) / SLOT_SIZE);
        int row = (int) ((mouseY - gridY) / SLOT_SIZE);
        if (col >= 0 && col < COLUMNS && row >= 0 && row < 6
                && mouseX >= gridX && mouseY >= gridY
                && mouseX < gridX + COLUMNS * SLOT_SIZE
                && mouseY < gridY + 6 * SLOT_SIZE) {
            int index = scroll * COLUMNS + row * COLUMNS + col;
            if (index < visibleItems.size() && minecraft.player.getAbilities().instabuild) {
                ItemStack stack = new ItemStack(visibleItems.get(index), 64);
                minecraft.gameMode.handleCreativeModeItemAdd(stack, 36);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        int rowsPerPage = 6;
        int pageCount = Math.max(1, (visibleItems.size() + COLUMNS * rowsPerPage - 1)
                / (COLUMNS * rowsPerPage));
        scroll = Math.max(0, Math.min(pageCount - 1, scroll - (int) Math.signum(deltaY)));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
