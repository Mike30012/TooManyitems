# TooManyItems – NeoForge 1.21.1

GitHub-ready Java 21 / Gradle project for **Minecraft 1.21.1 + NeoForge**.

## Build on GitHub

1. Create an empty GitHub repository.
2. Upload the contents of this project (the files inside this folder, not the outer ZIP).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build TooManyItems (NeoForge)** with **Run workflow**, or push a commit.
5. Open the completed workflow run and download the `TooManyItems-NeoForge-1.21.1` artifact.

The workflow runs `gradle build` and uploads the resulting mod JAR from `build/libs/`.

## Current implementation

- Press **O** in-game to open the item browser.
- Search by item name or registry ID.
- Scroll through the item list.
- In Creative mode, click an item to add a stack of 64 to the inventory.
- Press **Esc** to close.
- In every inventory/container screen: item list on the right with tabs (all items, favorites, enchanted books, potions, fireworks; Shift+click or F on an item adds/removes a favorite star) (left click = full stack, right click = 1, right click on the search box clears it), top toolbar (T trash mode, S/C/A game mode, Rain/Sun, Day/Night, Heal – these use vanilla commands and need cheats/op) and Save 1-7 on the left (empty: click saves, saved: click loads, Shift+click overwrites; files in `<game dir>/toomanyitems/`).

## Enchantment tab

The book tab is an editor like the original TooManyItems:

- Item button (left click: pick an item, right click: use the item in your hand), **Make** (gives the enchanted item), **Favorite** (saves it in the star tab until the game is closed), name field.
- Every enchantment of the game is listed with `- +` buttons (Shift = steps of 10). Click the number to type a level; right click the name to reset it. Enchantments the item cannot normally take are shown in red.
- Levels go 0, 1 ... 255 and then wrap: 256 shows -1, 257 shows -2 ... -255, then 0 again. Minecraft 1.21.1 only stores levels 1-255, so only levels of 1 or more end up on the item.

## Legacy source archive

The original 1.6.4 ZIP contains compiled `.class` files, not Java source. Those files and the old texture are retained in `legacy-1.6.4/` as reference material. They cannot be used unchanged on 1.21.1, so this is a clean recreation starter, not a complete port of every legacy panel and feature.

## Local build (optional)

Install a Java 21 JDK, then run `gradle build`. The output is in `build/libs/`.
