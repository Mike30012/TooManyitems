package de.example.toomanyitems.client;

import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Enchanted items saved with the "Favorite" button of the enchantment tab (kept until the game is closed). */
final class EnchantPresets {
    private static final List<ItemStack> PRESETS = new ArrayList<>();

    private EnchantPresets() {}

    static void add(ItemStack stack) {
        for (ItemStack existing : PRESETS) {
            if (ItemStack.isSameItemSameComponents(existing, stack)) return;
        }
        PRESETS.add(stack.copy());
    }

    /** Removes the preset that is this exact stack object (as listed in the favorites tab). */
    static boolean remove(ItemStack stack) {
        for (int i = 0; i < PRESETS.size(); i++) {
            if (PRESETS.get(i) == stack) {
                PRESETS.remove(i);
                return true;
            }
        }
        return false;
    }

    static List<ItemStack> all() {
        return PRESETS;
    }
}
