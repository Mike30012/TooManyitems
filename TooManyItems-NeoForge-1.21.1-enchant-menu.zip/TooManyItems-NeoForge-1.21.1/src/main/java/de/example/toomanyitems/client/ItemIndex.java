package de.example.toomanyitems.client;

import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.component.FireworkExplosion;
import net.minecraft.world.item.component.Fireworks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Builds the entry lists behind the tabs of the side panel. */
final class ItemIndex {
    /** One clickable entry: the stack to give plus lower-case text that the search box matches against. */
    record Entry(ItemStack stack, String search) {}

    enum Tab {
        ITEMS("All items"),
        FAVORITES("Favorites (Shift+click or F on an item adds/removes it)"),
        ENCHANTS("Enchantments"),
        POTIONS("Potions"),
        FIREWORKS("Fireworks");

        final String title;

        Tab(String title) {
            this.title = title;
        }
    }

    private static List<Entry> allItems;

    private ItemIndex() {}

    static List<Entry> entries(Tab tab) {
        return switch (tab) {
            case ITEMS -> items();
            case FAVORITES -> favorites();
            case ENCHANTS -> new ArrayList<>(); // the enchantment tab is an editor drawn by SidePanel
            case POTIONS -> potions();
            case FIREWORKS -> fireworks();
        };
    }

    private static Entry itemEntry(Item item) {
        ItemStack stack = new ItemStack(item);
        String id = BuiltInRegistries.ITEM.getKey(item).toString();
        return new Entry(stack, (id + " " + stack.getHoverName().getString()).toLowerCase(Locale.ROOT));
    }

    private static List<Entry> items() {
        if (allItems == null) {
            List<Item> sorted = new ArrayList<>();
            BuiltInRegistries.ITEM.stream().filter(item -> item != Items.AIR).forEach(sorted::add);
            sorted.sort(Comparator.comparing(item -> BuiltInRegistries.ITEM.getKey(item).toString()));
            List<Entry> list = new ArrayList<>();
            for (Item item : sorted) list.add(itemEntry(item));
            allItems = list;
        }
        return allItems;
    }

    private static List<Entry> favorites() {
        List<Entry> list = new ArrayList<>();
        for (ResourceLocation id : Favorites.all()) {
            BuiltInRegistries.ITEM.getOptional(id).filter(item -> item != Items.AIR)
                    .ifPresent(item -> list.add(itemEntry(item)));
        }
        // enchanted items saved with the "Favorite" button of the enchantment tab
        for (ItemStack preset : EnchantPresets.all()) {
            list.add(new Entry(preset, (BuiltInRegistries.ITEM.getKey(preset.getItem()) + " "
                    + preset.getHoverName().getString()).toLowerCase(Locale.ROOT)));
        }
        return list;
    }

    private static List<Entry> potions() {
        List<Entry> list = new ArrayList<>();
        Item[] bases = {Items.POTION, Items.SPLASH_POTION, Items.LINGERING_POTION, Items.TIPPED_ARROW};
        for (Item base : bases) {
            BuiltInRegistries.POTION.holders().forEach(holder -> {
                if (holder.key().location().getPath().equals("empty")) return;
                ItemStack stack = PotionContents.createItemStack(base, holder);
                list.add(new Entry(stack, (holder.key().location() + " "
                        + stack.getHoverName().getString()).toLowerCase(Locale.ROOT)));
            });
        }
        return list;
    }

    private static List<Entry> fireworks() {
        List<Entry> list = new ArrayList<>();
        for (int flight = 1; flight <= 3; flight++) {
            ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
            rocket.set(DataComponents.FIREWORKS, new Fireworks(flight, List.of()));
            list.add(new Entry(rocket, "firework rocket flight " + flight));
        }
        for (int flight = 1; flight <= 3; flight++) {
            for (DyeColor color : DyeColor.values()) {
                FireworkExplosion explosion = new FireworkExplosion(FireworkExplosion.Shape.LARGE_BALL,
                        IntList.of(color.getFireworkColor()), IntList.of(), false, false);
                ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
                rocket.set(DataComponents.FIREWORKS, new Fireworks(flight, List.of(explosion)));
                list.add(new Entry(rocket, "firework rocket flight " + flight + " " + color.getName()));
            }
        }
        for (FireworkExplosion.Shape shape : FireworkExplosion.Shape.values()) {
            for (DyeColor color : DyeColor.values()) {
                FireworkExplosion explosion = new FireworkExplosion(shape,
                        IntList.of(color.getFireworkColor()), IntList.of(), false, false);
                ItemStack star = new ItemStack(Items.FIREWORK_STAR);
                star.set(DataComponents.FIREWORK_EXPLOSION, explosion);
                list.add(new Entry(star, "firework star " + shape.getName() + " " + color.getName()));
            }
        }
        return list;
    }
}
