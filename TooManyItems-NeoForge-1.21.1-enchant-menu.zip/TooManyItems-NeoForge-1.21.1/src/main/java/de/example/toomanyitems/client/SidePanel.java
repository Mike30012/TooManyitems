package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The panel docked to the right of the inventory: tabs, search box, item grid, page arrows.
 * The "Enchantments" tab is an editor instead of a grid: item button, Make / Favorite, name field and one
 * "- + Name level" row for every enchantment in the game.
 */
final class SidePanel extends AbstractWidget {
    private static final int CELL = 18;
    private static final int TAB_HEIGHT = 18;
    private static final int SEARCH_Y = 20;
    private static final int GRID_OFFSET = 40;

    // Enchantment editor layout (relative to the panel).
    private static final int NAME_Y = 40;
    private static final int LIST_OFFSET = 60;
    private static final int ROW_H = 12;
    private static final int BTN_AREA = 22; // width of the "- +" buttons in front of every row

    /**
     * Enchantment levels run through 0, 1 ... 255 and then wrap to -1, -2 ... -255 (so 256 shows as -1,
     * 257 as -2 and so on) before starting again at 0. {@code PERIOD} is the length of that cycle.
     */
    private static final int MAX_LEVEL = 255;
    private static final int PERIOD = 2 * MAX_LEVEL + 1;

    // Static so the tab, search text and scroll position survive the screen being rebuilt (window resize).
    private static String query = "";
    private static int scroll = 0;
    private static ItemIndex.Tab tab = ItemIndex.Tab.ITEMS;

    // Static state of the enchantment editor.
    private static ItemStack selectedItem;
    private static String enchName = "";
    private static boolean pickerOpen = false;
    private static final Map<ResourceLocation, Integer> LEVEL_INDEX = new HashMap<>();
    private static List<ItemStack> pickerItems;

    private final Font font;
    private final EditBox search;
    private final EditBox nameField;
    private final int cols;
    private final int rows;
    private final ItemStack[] tabIcons = new ItemStack[ItemIndex.Tab.values().length];
    private List<ItemIndex.Entry> base;
    private List<ItemIndex.Entry> entries = new ArrayList<>();
    private ItemIndex.Entry hovered;

    private List<Holder.Reference<Enchantment>> enchants = new ArrayList<>();
    private int editRow = -1; // index into enchants of the level being typed, or -1
    private String editText = "";

    SidePanel(Font font, int x, int y, int cols, int rows) {
        super(x, y, cols * CELL, GRID_OFFSET + rows * CELL + 14, Component.literal("TooManyItems"));
        this.font = font;
        this.cols = cols;
        this.rows = rows;

        tabIcons[ItemIndex.Tab.ITEMS.ordinal()] = new ItemStack(Items.CRAFTING_TABLE);
        tabIcons[ItemIndex.Tab.ENCHANTS.ordinal()] = new ItemStack(Items.ENCHANTED_BOOK);
        tabIcons[ItemIndex.Tab.POTIONS.ordinal()] = PotionContents.createItemStack(Items.POTION, Potions.HEALING);
        tabIcons[ItemIndex.Tab.FIREWORKS.ordinal()] = new ItemStack(Items.FIREWORK_ROCKET);

        if (selectedItem == null) selectedItem = new ItemStack(Items.DIAMOND_SWORD);

        this.search = new EditBox(font, x + 1, y + SEARCH_Y, cols * CELL - 2, 16, Component.literal("Search items"));
        search.setHint(Component.literal("Search..."));
        search.setValue(query);
        search.setResponder(value -> {
            query = value;
            scroll = 0;
            applyFilter();
        });

        this.nameField = new EditBox(font, x + 1, y + NAME_Y, cols * CELL - 2, 16, Component.literal("Item name"));
        nameField.setHint(Component.literal("Name..."));
        nameField.setMaxLength(100);
        nameField.setValue(enchName);
        nameField.setResponder(value -> enchName = value);

        loadEnchants();
        this.base = ItemIndex.entries(tab);
        applyFilter();
    }

    // ---------------------------------------------------------------- data

    private void applyFilter() {
        String needle = query.toLowerCase(Locale.ROOT).trim();
        if (needle.isEmpty()) {
            entries = base;
        } else {
            List<ItemIndex.Entry> filtered = new ArrayList<>();
            for (ItemIndex.Entry entry : base) {
                if (entry.search().contains(needle)) filtered.add(entry);
            }
            entries = filtered;
        }
        clampScroll();
    }

    private void setTab(ItemIndex.Tab newTab) {
        tab = newTab;
        scroll = 0;
        pickerOpen = false;
        stopEdit();
        if (newTab == ItemIndex.Tab.ENCHANTS && enchants.isEmpty()) loadEnchants();
        base = ItemIndex.entries(newTab);
        applyFilter();
    }

    private boolean enchantMode() {
        return tab == ItemIndex.Tab.ENCHANTS;
    }

    private int maxScroll() {
        if (enchantMode()) {
            if (pickerOpen) {
                int pickerRows = (pickerItems().size() + cols - 1) / cols;
                return Math.max(0, pickerRows - rows);
            }
            return Math.max(0, enchants.size() - listRows());
        }
        int totalRows = (entries.size() + cols - 1) / cols;
        return Math.max(0, totalRows - rows);
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
    }

    /** How far the "<" / ">" arrows move the view. */
    private int pageStep() {
        return enchantMode() && !pickerOpen ? listRows() : rows;
    }

    private boolean canFavorite() {
        return tab == ItemIndex.Tab.ITEMS || tab == ItemIndex.Tab.FAVORITES;
    }

    private void toggleFavorite(ItemIndex.Entry entry) {
        // Saved enchantment presets live in the favorites tab; toggling one removes it again.
        if (EnchantPresets.remove(entry.stack())) {
            ItemGiver.message("Removed from favorites");
            if (tab == ItemIndex.Tab.FAVORITES) {
                base = ItemIndex.entries(tab);
                applyFilter();
            }
            return;
        }
        boolean added = Favorites.toggle(BuiltInRegistries.ITEM.getKey(entry.stack().getItem()));
        ItemGiver.message(added ? "Added to favorites" : "Removed from favorites");
        if (tab == ItemIndex.Tab.FAVORITES) {
            base = ItemIndex.entries(tab);
            applyFilter();
        }
    }

    // ---------------------------------------------------------------- enchantment editor: data

    /** Items offered by the item button. */
    private static List<ItemStack> pickerItems() {
        if (pickerItems == null) {
            pickerItems = new ArrayList<>();
            net.minecraft.world.item.Item[] items = {
                    Items.DIAMOND_SWORD, Items.NETHERITE_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE,
                    Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE, Items.BOW, Items.CROSSBOW, Items.TRIDENT,
                    Items.MACE, Items.FISHING_ROD, Items.SHEARS, Items.FLINT_AND_STEEL, Items.SHIELD,
                    Items.ELYTRA, Items.CARROT_ON_A_STICK, Items.WARPED_FUNGUS_ON_A_STICK, Items.BRUSH,
                    Items.TURTLE_HELMET, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE,
                    Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS, Items.NETHERITE_HELMET,
                    Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS,
                    Items.ENCHANTED_BOOK
            };
            for (net.minecraft.world.item.Item item : items) pickerItems.add(new ItemStack(item));
        }
        return pickerItems;
    }

    /** Loads every enchantment of the current world (vanilla, modded and data pack ones). */
    private void loadEnchants() {
        enchants = new ArrayList<>();
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Registry<Enchantment> registry = mc.level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
        registry.holders().forEach(enchants::add);
        sortEnchants();
    }

    /** Enchantments that fit the selected item first, the rest below (shown in red). */
    private void sortEnchants() {
        enchants.sort((a, b) -> {
            boolean sa = supported(a);
            boolean sb = supported(b);
            if (sa != sb) return sa ? -1 : 1;
            return nameOf(a).compareToIgnoreCase(nameOf(b));
        });
    }

    private static boolean supported(Holder.Reference<Enchantment> holder) {
        return holder.value().isSupportedItem(selectedItem);
    }

    private static String nameOf(Holder.Reference<Enchantment> holder) {
        return holder.value().description().getString();
    }

    private static int indexOf(Holder.Reference<Enchantment> holder) {
        return LEVEL_INDEX.getOrDefault(holder.key().location(), 0);
    }

    private static void setIndex(Holder.Reference<Enchantment> holder, int index) {
        int wrapped = ((index % PERIOD) + PERIOD) % PERIOD;
        if (wrapped == 0) LEVEL_INDEX.remove(holder.key().location());
        else LEVEL_INDEX.put(holder.key().location(), wrapped);
    }

    /** Position in the cycle -> the level shown: 0..255, then -1..-255. */
    private static int levelOf(int index) {
        return index <= MAX_LEVEL ? index : MAX_LEVEL - index;
    }

    /** A typed number -> position in the cycle, so that 256 gives -1, 257 gives -2 and so on. */
    private static int indexFromLevel(long typed) {
        long index = typed >= 0 ? typed % PERIOD : (MAX_LEVEL - typed) % PERIOD;
        return (int) index;
    }

    private static long parseTyped(String text) {
        if (text.isEmpty() || text.equals("-")) return 0;
        try {
            return Long.parseLong(text);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private int shownLevel(int row) {
        Holder.Reference<Enchantment> holder = enchants.get(row);
        if (row == editRow && !editText.isEmpty()) {
            return levelOf(indexFromLevel(parseTyped(editText)));
        }
        return levelOf(indexOf(holder));
    }

    private void applyEdit() {
        if (editRow < 0 || editRow >= enchants.size()) return;
        setIndex(enchants.get(editRow), indexFromLevel(parseTyped(editText)));
    }

    private void startEdit(int row) {
        editRow = row;
        editText = "";
        search.setFocused(false);
        nameField.setFocused(false);
    }

    private void stopEdit() {
        editRow = -1;
        editText = "";
    }

    /** The item with all enchantments of level 1 or higher and the typed name. */
    private ItemStack buildStack() {
        ItemStack stack = selectedItem.copy();
        stack.setCount(1);
        ItemEnchantments.Mutable mutable = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
        for (Holder.Reference<Enchantment> holder : enchants) {
            int level = levelOf(indexOf(holder));
            if (level >= 1) mutable.set(holder, level);
        }
        ItemEnchantments result = mutable.toImmutable();
        if (!result.isEmpty()) {
            DataComponentType<ItemEnchantments> type = stack.is(Items.ENCHANTED_BOOK)
                    ? DataComponents.STORED_ENCHANTMENTS : DataComponents.ENCHANTMENTS;
            stack.set(type, result);
        }
        String name = enchName.trim();
        if (!name.isEmpty()) {
            stack.set(DataComponents.CUSTOM_NAME, Component.literal(name));
        }
        return stack;
    }

    private void chooseItem(ItemStack stack) {
        selectedItem = stack.copy();
        selectedItem.setCount(1);
        pickerOpen = false;
        scroll = 0;
        stopEdit();
        sortEnchants();
    }

    // ---------------------------------------------------------------- geometry

    private int gridY() {
        return getY() + GRID_OFFSET;
    }

    private int labelY() {
        return gridY() + rows * CELL + 3;
    }

    private int listY() {
        return getY() + LIST_OFFSET;
    }

    private int listRows() {
        return Math.max(1, (rows * CELL - 20) / ROW_H);
    }

    private int tabWidth() {
        return width / ItemIndex.Tab.values().length;
    }

    private int tabAt(double mouseX, double mouseY) {
        if (mouseY < getY() || mouseY >= getY() + TAB_HEIGHT || mouseX < getX() || mouseX >= getX() + width) return -1;
        return Math.min(ItemIndex.Tab.values().length - 1, (int) ((mouseX - getX()) / tabWidth()));
    }

    private ItemIndex.Entry entryAt(double mouseX, double mouseY) {
        if (enchantMode()) return null;
        if (mouseX < getX() || mouseY < gridY()
                || mouseX >= getX() + cols * CELL || mouseY >= gridY() + rows * CELL) return null;
        int col = (int) ((mouseX - getX()) / CELL);
        int row = (int) ((mouseY - gridY()) / CELL);
        int index = (scroll + row) * cols + col;
        return index < entries.size() ? entries.get(index) : null;
    }

    /** Index into pickerItems() under the mouse while the item picker is open, or -1. */
    private int pickerAt(double mouseX, double mouseY) {
        if (mouseX < getX() || mouseY < gridY()
                || mouseX >= getX() + cols * CELL || mouseY >= gridY() + rows * CELL) return -1;
        int col = (int) ((mouseX - getX()) / CELL);
        int row = (int) ((mouseY - gridY()) / CELL);
        int index = (scroll + row) * cols + col;
        return index < pickerItems().size() ? index : -1;
    }

    /** Row of the enchantment list under the mouse (index into enchants), or -1. */
    private int enchantRowAt(double mouseX, double mouseY) {
        if (mouseX < getX() || mouseX >= getX() + width || mouseY < listY()
                || mouseY >= listY() + listRows() * ROW_H) return -1;
        int index = scroll + (int) ((mouseY - listY()) / ROW_H);
        return index < enchants.size() ? index : -1;
    }

    private int itemBtnX() {
        return getX() + 1;
    }

    private int makeX() {
        return getX() + 24;
    }

    private int makeW() {
        return font.width("Make") + 10;
    }

    private int favX() {
        return makeX() + makeW() + 3;
    }

    private int favW() {
        return font.width("Favorite") + 10;
    }

    private static boolean inRect(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private boolean overItemBtn(double mx, double my) {
        return inRect(mx, my, itemBtnX(), getY() + SEARCH_Y - 1, 20, 18);
    }

    private boolean overMake(double mx, double my) {
        return inRect(mx, my, makeX(), getY() + SEARCH_Y, makeW(), 16);
    }

    private boolean overFavorite(double mx, double my) {
        return inRect(mx, my, favX(), getY() + SEARCH_Y, favW(), 16);
    }

    // ---------------------------------------------------------------- rendering

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(getX() - 2, getY() - 2, getX() + width + 2, getY() + height + 2, 0x70000000);

        renderTabs(graphics, mouseX, mouseY);

        if (enchantMode()) {
            hovered = null;
            if (pickerOpen) renderPicker(graphics, mouseX, mouseY);
            else renderEnchantEditor(graphics, mouseX, mouseY, partialTick);
            renderBottomBar(graphics, enchantTotal(), enchantFirst(), enchantLast());
            return;
        }

        search.render(graphics, mouseX, mouseY, partialTick);

        hovered = entryAt(mouseX, mouseY);
        int start = scroll * cols;
        for (int slot = 0; slot < cols * rows; slot++) {
            int x = getX() + (slot % cols) * CELL;
            int y = gridY() + (slot / cols) * CELL;
            graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80404040);
            int index = start + slot;
            if (index < entries.size()) {
                ItemIndex.Entry entry = entries.get(index);
                graphics.renderItem(entry.stack(), x + 1, y + 1);
                if (entry == hovered) {
                    graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80FFFFFF);
                }
                if (canFavorite() && Favorites.contains(BuiltInRegistries.ITEM.getKey(entry.stack().getItem()))) {
                    graphics.pose().pushPose();
                    graphics.pose().translate(0, 0, 200); // above the item model
                    Icons.draw(graphics, Icons.STAR_SMALL, x + CELL - 7, y - 1);
                    graphics.pose().popPose();
                }
            }
        }

        int total = entries.size();
        int first = total == 0 ? 0 : start + 1;
        int last = Math.min(total, start + cols * rows);
        renderBottomBar(graphics, total, first, last);
    }

    private void renderBottomBar(GuiGraphics graphics, int total, int first, int last) {
        graphics.drawString(font, "<", getX() + 3, labelY(), 0xFFFFFF);
        graphics.drawString(font, ">", getX() + width - 9, labelY(), 0xFFFFFF);
        graphics.drawCenteredString(font, first + "-" + last + " / " + total,
                getX() + width / 2, labelY(), 0xCCCCCC);
    }

    private int enchantTotal() {
        return pickerOpen ? pickerItems().size() : enchants.size();
    }

    private int enchantFirst() {
        int total = enchantTotal();
        if (total == 0) return 0;
        return pickerOpen ? scroll * cols + 1 : scroll + 1;
    }

    private int enchantLast() {
        int total = enchantTotal();
        return pickerOpen ? Math.min(total, scroll * cols + cols * rows) : Math.min(total, scroll + listRows());
    }

    private void drawButtonBox(GuiGraphics graphics, int x, int y, int w, int h, boolean hover) {
        graphics.fill(x, y, x + w, y + h, 0xFF0E0E10);
        graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, hover ? 0xFF58606E : 0xFF353B47);
        graphics.fill(x + 1, y + 1, x + w - 1, y + 2, 0x40FFFFFF);
    }

    private void renderEnchantEditor(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int cy = getY() + SEARCH_Y;

        // item button + Make + Favorite
        drawButtonBox(graphics, itemBtnX(), cy - 1, 20, 18, overItemBtn(mouseX, mouseY));
        graphics.renderItem(selectedItem, itemBtnX() + 2, cy);

        drawButtonBox(graphics, makeX(), cy, makeW(), 16, overMake(mouseX, mouseY));
        graphics.drawCenteredString(font, "Make", makeX() + makeW() / 2, cy + 4, 0xFFFFFF);

        drawButtonBox(graphics, favX(), cy, favW(), 16, overFavorite(mouseX, mouseY));
        graphics.drawCenteredString(font, "Favorite", favX() + favW() / 2, cy + 4, 0xFFFFFF);

        nameField.render(graphics, mouseX, mouseY, partialTick);

        // one row per enchantment
        int hoverRow = enchantRowAt(mouseX, mouseY);
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        for (int r = 0; r < listRows(); r++) {
            int index = scroll + r;
            if (index >= enchants.size()) break;
            Holder.Reference<Enchantment> holder = enchants.get(index);
            int y = listY() + r * ROW_H;
            int color = supported(holder) ? 0xFFFFFFFF : 0xFF9A4A4A;

            if (index == hoverRow) {
                graphics.fill(getX(), y, getX() + width, y + ROW_H, 0x30FFFFFF);
            }
            graphics.drawString(font, "-", getX() + 3, y + 2, color);
            graphics.drawString(font, "+", getX() + 13, y + 2, color);

            String level = Integer.toString(shownLevel(index));
            if (index == editRow && blink) level = level + "_";
            String name = nameOf(holder);
            int room = width - BTN_AREA - 4 - font.width(" " + level);
            if (font.width(name) > room) name = font.plainSubstrByWidth(name, Math.max(0, room));
            graphics.drawString(font, name + " " + level, getX() + BTN_AREA, y + 2,
                    index == editRow ? 0xFFFFFF55 : color);
        }
    }

    private void renderPicker(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, "Choose item", getX() + 3, getY() + SEARCH_Y + 4, 0xFFFFFF);
        int hover = pickerAt(mouseX, mouseY);
        int start = scroll * cols;
        List<ItemStack> list = pickerItems();
        for (int slot = 0; slot < cols * rows; slot++) {
            int x = getX() + (slot % cols) * CELL;
            int y = gridY() + (slot / cols) * CELL;
            graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80404040);
            int index = start + slot;
            if (index < list.size()) {
                graphics.renderItem(list.get(index), x + 1, y + 1);
                if (index == hover) {
                    graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80FFFFFF);
                }
            }
        }
    }

    private void renderTabs(GuiGraphics graphics, int mouseX, int mouseY) {
        ItemIndex.Tab[] tabs = ItemIndex.Tab.values();
        int tabWidth = tabWidth();
        int hoveredTab = tabAt(mouseX, mouseY);
        for (int i = 0; i < tabs.length; i++) {
            int x = getX() + i * tabWidth;
            int y = getY();
            int w = tabWidth - 2;
            int h = TAB_HEIGHT - 2;
            int face = tabs[i] == tab ? 0xFF3C5A8A : (i == hoveredTab ? 0xFF58606E : 0xFF353B47);
            graphics.fill(x, y, x + w, y + h, 0xFF0E0E10);
            graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, face);
            graphics.fill(x + 1, y + 1, x + w - 1, y + 2, 0x40FFFFFF);
            if (tabs[i] == ItemIndex.Tab.FAVORITES) {
                Icons.draw(graphics, Icons.STAR, x + (w - Icons.SIZE) / 2, y + (h - Icons.SIZE) / 2);
            } else {
                graphics.renderItem(tabIcons[i], x + (w - 16) / 2, y + (h - 16) / 2);
            }
        }
    }

    /** Called after the whole screen is drawn so tooltips are not painted over. */
    void renderLate(GuiGraphics graphics, int mouseX, int mouseY) {
        int tabIndex = tabAt(mouseX, mouseY);
        if (tabIndex >= 0) {
            graphics.renderTooltip(font, Component.literal(ItemIndex.Tab.values()[tabIndex].title), mouseX, mouseY);
            return;
        }
        if (enchantMode()) {
            if (pickerOpen) {
                int index = pickerAt(mouseX, mouseY);
                if (index >= 0) {
                    ItemStack stack = pickerItems().get(index);
                    List<Component> lines = Screen.getTooltipFromItem(Minecraft.getInstance(), stack);
                    graphics.renderTooltip(font, lines, stack.getTooltipImage(), mouseX, mouseY);
                } else {
                    graphics.renderTooltip(font, Component.literal("Right click: back"), mouseX, mouseY);
                }
            } else if (overItemBtn(mouseX, mouseY)) {
                graphics.renderTooltip(font, Component.literal("Click: choose item, right click: use held item"),
                        mouseX, mouseY);
            } else if (overMake(mouseX, mouseY)) {
                graphics.renderTooltip(font, Component.literal("Give the enchanted item"), mouseX, mouseY);
            } else if (overFavorite(mouseX, mouseY)) {
                graphics.renderTooltip(font, Component.literal("Save the enchanted item in the favorites tab"),
                        mouseX, mouseY);
            }
            return;
        }
        ItemIndex.Entry entry = entryAt(mouseX, mouseY);
        if (entry != null) {
            List<Component> lines = Screen.getTooltipFromItem(Minecraft.getInstance(), entry.stack());
            graphics.renderTooltip(font, lines, entry.stack().getTooltipImage(), mouseX, mouseY);
        }
    }

    // ---------------------------------------------------------------- input

    private void unfocusAll() {
        search.setFocused(false);
        nameField.setFocused(false);
        stopEdit();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isMouseOver(mouseX, mouseY)) {
            unfocusAll();
            return false;
        }

        int tabIndex = tabAt(mouseX, mouseY);
        if (tabIndex >= 0) {
            unfocusAll();
            setTab(ItemIndex.Tab.values()[tabIndex]);
            return true;
        }

        if (enchantMode()) return clickEnchantEditor(mouseX, mouseY, button);

        if (mouseY >= getY() + SEARCH_Y && mouseY < getY() + SEARCH_Y + 17) {
            search.setFocused(true);
            if (button == 1) search.setValue(""); // right click clears the search
            else search.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        search.setFocused(false);

        ItemIndex.Entry entry = entryAt(mouseX, mouseY);
        if (entry != null) {
            if (button == 0 && Screen.hasShiftDown() && canFavorite()) {
                toggleFavorite(entry);
            } else {
                ItemGiver.give(Minecraft.getInstance(), entry.stack(), button == 0);
            }
            return true;
        }
        if (mouseY >= labelY() - 2) {
            if (mouseX < getX() + 20) scroll -= rows;
            else if (mouseX > getX() + width - 20) scroll += rows;
            clampScroll();
        }
        return true;
    }

    private boolean clickEnchantEditor(double mouseX, double mouseY, int button) {
        // page arrows at the bottom work in every mode
        if (mouseY >= labelY() - 2) {
            stopEdit();
            if (mouseX < getX() + 20) scroll -= pageStep();
            else if (mouseX > getX() + width - 20) scroll += pageStep();
            clampScroll();
            return true;
        }

        if (pickerOpen) {
            int index = pickerAt(mouseX, mouseY);
            if (index >= 0 && button == 0) chooseItem(pickerItems().get(index));
            else if (button == 1) {
                pickerOpen = false;
                scroll = 0;
            }
            return true;
        }

        Minecraft mc = Minecraft.getInstance();

        if (overItemBtn(mouseX, mouseY)) {
            unfocusAll();
            if (button == 1) {
                if (mc.player != null && !mc.player.getMainHandItem().isEmpty()) {
                    chooseItem(mc.player.getMainHandItem());
                } else {
                    ItemGiver.message("Hold an item in your hand first");
                }
            } else {
                pickerOpen = true;
                scroll = 0;
            }
            return true;
        }

        if (overMake(mouseX, mouseY)) {
            unfocusAll();
            ItemGiver.give(mc, buildStack(), false);
            return true;
        }

        if (overFavorite(mouseX, mouseY)) {
            unfocusAll();
            EnchantPresets.add(buildStack());
            ItemGiver.message("Saved in the favorites tab");
            return true;
        }

        if (mouseY >= getY() + NAME_Y && mouseY < getY() + NAME_Y + 17) {
            stopEdit();
            search.setFocused(false);
            nameField.setFocused(true);
            if (button == 1) nameField.setValue(""); // right click clears the name
            else nameField.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        nameField.setFocused(false);

        int row = enchantRowAt(mouseX, mouseY);
        if (row >= 0) {
            Holder.Reference<Enchantment> holder = enchants.get(row);
            int step = Screen.hasShiftDown() ? 10 : 1;
            if (mouseX < getX() + 12) {
                stopEdit();
                setIndex(holder, indexOf(holder) - step);
            } else if (mouseX < getX() + BTN_AREA) {
                stopEdit();
                setIndex(holder, indexOf(holder) + step);
            } else if (button == 1) {
                stopEdit();
                setIndex(holder, 0); // right click on the name resets it to 0
            } else {
                startEdit(row); // click on the number: type a level
            }
            return true;
        }
        stopEdit();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        scroll -= (int) Math.signum(scrollY);
        clampScroll();
        return true;
    }

    /** True while a text box of the current tab (search, name or a level) has the keyboard. */
    private boolean typing() {
        if (enchantMode()) return editRow >= 0 || nameField.isFocused();
        return search.isFocused();
    }

    /**
     * Key/char forwarding. InventoryOverlay calls these from screen events (before the screen sees the
     * key), because e.g. the Creative inventory ignores typed characters in most tabs and uses "T" to
     * jump to its own search tab.
     */
    boolean handleKey(int keyCode, int scanCode, int modifiers) {
        if (!typing()) {
            // "F" over an item toggles its favorite star (handy where Shift is hard to press).
            if (keyCode == GLFW.GLFW_KEY_F && hovered != null && canFavorite()) {
                toggleFavorite(hovered);
                return true;
            }
            return false;
        }
        if (enchantMode() && editRow >= 0) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER
                    || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                stopEdit(); // finish typing; Escape does not close the screen this time
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editText.isEmpty()) {
                    editText = editText.substring(0, editText.length() - 1);
                    applyEdit();
                }
            }
            return true; // swallow every key while typing a level
        }
        if (keyCode == 256) return false; // let Escape close the screen
        if (enchantMode()) nameField.keyPressed(keyCode, scanCode, modifiers);
        else search.keyPressed(keyCode, scanCode, modifiers);
        return true; // swallow every other key so "E" does not close the inventory
    }

    boolean handleChar(char codePoint, int modifiers) {
        if (!typing()) return false;
        if (enchantMode() && editRow >= 0) {
            if (Character.isDigit(codePoint) && editText.length() < 9) {
                editText += codePoint;
                applyEdit();
            } else if (codePoint == '-' && editText.isEmpty()) {
                editText = "-";
            }
            return true;
        }
        if (enchantMode()) nameField.charTyped(codePoint, modifiers);
        else search.charTyped(codePoint, modifiers);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return handleKey(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        return handleChar(codePoint, modifiers);
    }

    @Override
    public void setFocused(boolean focused) {
        super.setFocused(focused);
        if (!focused) unfocusAll();
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, getMessage());
    }
}
