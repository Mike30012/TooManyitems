package de.example.toomanyitems;

import net.neoforged.fml.common.Mod;

@Mod(TooManyItems.MOD_ID)
public final class TooManyItems {
    public static final String MOD_ID = "toomanyitems";

    public TooManyItems() {
        // Client controls and screens are registered by the client-only event subscriber.
    }
}
