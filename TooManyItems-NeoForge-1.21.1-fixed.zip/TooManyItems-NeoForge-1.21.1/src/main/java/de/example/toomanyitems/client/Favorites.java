package de.example.toomanyitems.client;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The star tab: item ids stored one per line in toomanyitems/favorites.txt. */
final class Favorites {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Set<ResourceLocation> IDS = new LinkedHashSet<>();
    private static boolean loaded;

    private Favorites() {}

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("toomanyitems").resolve("favorites.txt");
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file())) {
                    ResourceLocation id = ResourceLocation.tryParse(line.trim());
                    if (id != null) IDS.add(id);
                }
            }
        } catch (IOException e) {
            LOGGER.error("Could not read favorites", e);
        }
    }

    private static void save() {
        try {
            Files.createDirectories(file().getParent());
            List<String> lines = new ArrayList<>();
            for (ResourceLocation id : IDS) lines.add(id.toString());
            Files.write(file(), lines);
        } catch (IOException e) {
            LOGGER.error("Could not save favorites", e);
        }
    }

    static boolean contains(ResourceLocation id) {
        load();
        return IDS.contains(id);
    }

    /** @return true if the item is now a favorite, false if it was removed. */
    static boolean toggle(ResourceLocation id) {
        load();
        boolean added = IDS.add(id);
        if (!added) IDS.remove(id);
        save();
        return added;
    }

    static List<ResourceLocation> all() {
        load();
        return new ArrayList<>(IDS);
    }
}
