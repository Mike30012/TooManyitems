package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;

/** Small flat toolbar button showing either a pixel icon or a single letter, like the classic TMI bar. */
final class IconButton extends AbstractButton {
    static final int SIZE = 16;
    private static final int DEFAULT_ON = 0xFF3C5A8A;

    private final int[][] icon;
    private final String letter;
    private final Runnable action;
    private final BooleanSupplier toggled;
    private final int toggledColor;

    IconButton(int x, int y, int[][] icon, String letter, String tooltip,
               Runnable action, BooleanSupplier toggled, int toggledColor) {
        super(x, y, SIZE, SIZE, Component.literal(tooltip));
        this.icon = icon;
        this.letter = letter;
        this.action = action;
        this.toggled = toggled;
        this.toggledColor = toggledColor;
        setTooltip(Tooltip.create(Component.literal(tooltip)));
    }

    static IconButton icon(int x, int[][] icon, String tooltip, Runnable action) {
        return new IconButton(x, 2, icon, null, tooltip, action, () -> false, DEFAULT_ON);
    }

    static IconButton letter(int x, String letter, String tooltip, Runnable action, BooleanSupplier toggled) {
        return new IconButton(x, 2, null, letter, tooltip, action, toggled, DEFAULT_ON);
    }

    static IconButton toggle(int x, int[][] icon, String tooltip, Runnable action,
                             BooleanSupplier toggled, int toggledColor) {
        return new IconButton(x, 2, icon, null, tooltip, action, toggled, toggledColor);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        defaultButtonNarrationText(output);
    }

    @Override
    public void onPress() {
        action.run();
    }

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int x = getX();
        int y = getY();
        boolean on = toggled.getAsBoolean();
        int background = on ? toggledColor : (isHoveredOrFocused() ? 0xFF58606E : 0xFF353B47);

        graphics.fill(x, y, x + width, y + height, 0xFF0E0E10);                 // outline
        graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, background);  // face
        graphics.fill(x + 1, y + 1, x + width - 1, y + 2, 0x40FFFFFF);           // top highlight
        graphics.fill(x + 1, y + height - 2, x + width - 1, y + height - 1, 0x40000000); // bottom shade

        if (icon != null) {
            int ox = x + (width - Icons.SIZE) / 2;
            int oy = y + (height - Icons.SIZE) / 2;
            Icons.draw(graphics, icon, ox, oy);
        } else if (letter != null) {
            var font = Minecraft.getInstance().font;
            graphics.drawString(font, letter, x + (width - font.width(letter)) / 2 + 0,
                    y + (height - 8) / 2 + 1, on ? 0xFFFFFF55 : 0xFFFFFFFF, true);
        }
    }
}
