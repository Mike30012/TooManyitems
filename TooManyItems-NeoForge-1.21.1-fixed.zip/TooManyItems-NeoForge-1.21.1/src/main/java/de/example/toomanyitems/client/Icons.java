package de.example.toomanyitems.client;

import net.minecraft.client.gui.GuiGraphics;

import java.util.Map;

/** 12x12 pixel icons (ARGB, 0 = transparent) for the toolbar, drawn in code so no textures are needed. */
final class Icons {
    static final int SIZE = 12;

    static final int[][] TRASH = parse(new String[] {
            "....rrrr....",
            ".RRRRRRRRRR.",
            ".RRRRRRRRRR.",
            "..GGGGGGGG..",
            "..GgdgdgdG..",
            "..GgdgdgdG..",
            "..GgdgdgdG..",
            "..GgdgdgdG..",
            "..GgdgdgdG..",
            "..GgdgdgdG..",
            "..GGGGGGGG..",
            "............"},
            Map.of('r', 0xFFA02010, 'R', 0xFFE04020, 'G', 0xFF707070, 'g', 0xFFC8C8C8, 'd', 0xFF8A8A8A));

    static final int[][] RAIN = parse(new String[] {
            ".....bb.....",
            ".....bb.....",
            "....bBBb....",
            "....bBBb....",
            "...bBwBBb...",
            "...bBwBBb...",
            "..bBBBBBBb..",
            "..bBBBBBBb..",
            "..bBBBBBBb..",
            "...bBBBBb...",
            "....bbbb....",
            "............"},
            Map.of('b', 0xFF2050B0, 'B', 0xFF3F7FE0, 'w', 0xFFBFE0FF));

    static final int[][] HEART = parse(new String[] {
            "............",
            "..rrr..rrr..",
            ".rRRRrrRRRr.",
            ".rRwRRRRRRr.",
            ".rRRRRRRRRr.",
            ".rRRRRRRRRr.",
            "..rRRRRRRr..",
            "...rRRRRr...",
            "....rRRr....",
            ".....rr.....",
            "............",
            "............"},
            Map.of('r', 0xFFA01818, 'R', 0xFFE03030, 'w', 0xFFFFB0B0));

    static final int[][] STAR = star();
    static final int[][] STAR_SMALL = smallStar();
    static final int[][] SUNRISE = sunrise();
    static final int[][] SUN = sun();
    static final int[][] DUSK = moon(0xFF7C9CFF, 0xFF3050C0);
    static final int[][] MIDNIGHT = moon(0xFFF2F2F2, 0xFFAAAAAA);

    private Icons() {}

    static void draw(GuiGraphics graphics, int[][] icon, int x, int y) {
        for (int py = 0; py < SIZE; py++) {
            for (int px = 0; px < SIZE; px++) {
                int color = icon[py][px];
                if (color != 0) graphics.fill(x + px, y + py, x + px + 1, y + py + 1, color);
            }
        }
    }

    /** Even-odd point-in-polygon test for a five-pointed star pointing up. */
    private static boolean inStar(double px, double py, double outer, double inner) {
        double[] xs = new double[10];
        double[] ys = new double[10];
        for (int i = 0; i < 10; i++) {
            double r = i % 2 == 0 ? outer : inner;
            double a = -Math.PI / 2 + i * Math.PI / 5;
            xs[i] = 6 + Math.cos(a) * r;
            ys[i] = 6.4 + Math.sin(a) * r;
        }
        boolean inside = false;
        for (int i = 0, j = 9; i < 10; j = i++) {
            if ((ys[i] > py) != (ys[j] > py)
                    && px < (xs[j] - xs[i]) * (py - ys[i]) / (ys[j] - ys[i]) + xs[i]) {
                inside = !inside;
            }
        }
        return inside;
    }

    /** A compact star marker (drawn in the 12x12 grid's top-left corner) for favorited items. */
    private static int[][] smallStar() {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                double px = x + 0.5;
                double py = y + 0.5;
                // same star, shrunk to about half size and moved into the top-left corner
                if (inStar(px * 2 - 0.0, py * 2 - 0.4, 5.9, 2.5)) {
                    grid[y][x] = inStar(px * 2, py * 2 - 0.4, 4.6, 1.9) ? 0xFFFFE23C : 0xFFD89A10;
                }
            }
        }
        return grid;
    }

    private static int[][] star() {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                double px = x + 0.5;
                double py = y + 0.5;
                if (inStar(px, py, 5.9, 2.5)) {
                    grid[y][x] = inStar(px, py, 4.6, 1.9) ? 0xFFFFE23C : 0xFFD89A10;
                }
            }
        }
        return grid;
    }

    private static int[][] parse(String[] rows, Map<Character, Integer> colors) {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                char c = rows[y].charAt(x);
                grid[y][x] = c == '.' ? 0 : colors.get(c);
            }
        }
        return grid;
    }

    private static void ray(int[][] grid, double cx, double cy, double angle, double dist, int color) {
        int x = (int) Math.floor(cx + Math.cos(angle) * dist);
        int y = (int) Math.floor(cy + Math.sin(angle) * dist);
        if (x >= 0 && x < SIZE && y >= 0 && y < SIZE) grid[y][x] = color;
    }

    private static int[][] sun() {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                double d = Math.hypot(x + 0.5 - 6, y + 0.5 - 6);
                if (d <= 3.3) grid[y][x] = d > 2.5 ? 0xFFD06010 : 0xFFFFA020;
            }
        }
        for (int k = 0; k < 8; k++) {
            ray(grid, 6, 6, k * Math.PI / 4, 4.3, 0xFFFFE060);
            ray(grid, 6, 6, k * Math.PI / 4, 5.3, 0xFFFFE060);
        }
        return grid;
    }

    private static int[][] sunrise() {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y <= 7; y++) {
            for (int x = 0; x < SIZE; x++) {
                double d = Math.hypot(x + 0.5 - 6, y + 0.5 - 8);
                if (d <= 3.6) grid[y][x] = d > 2.8 ? 0xFFD06010 : 0xFFFFA020;
            }
        }
        for (int k = 0; k <= 4; k++) {
            ray(grid, 6, 8, Math.PI + k * Math.PI / 4, 4.6, 0xFFFFE060);
            ray(grid, 6, 8, Math.PI + k * Math.PI / 4, 5.6, 0xFFFFE060);
        }
        for (int x = 0; x < SIZE; x++) grid[8][x] = 0xFFA0A0A0; // horizon
        return grid;
    }

    private static int[][] moon(int main, int edge) {
        int[][] grid = new int[SIZE][SIZE];
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                double px = x + 0.5;
                double py = y + 0.5;
                double outer = Math.hypot(px - 5.5, py - 6.2);
                double cut = Math.hypot(px - 8.4, py - 4.6);
                if (outer <= 5.3 && cut > 4.7) grid[y][x] = outer > 4.3 ? edge : main;
            }
        }
        return grid;
    }
}
