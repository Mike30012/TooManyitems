package de.example.toomanyitems.client;

import de.example.toomanyitems.TooManyItems;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Adds the classic TMI overlay (toolbar, save slots, item list) to inventory/container screens. */
@EventBusSubscriber(modid = TooManyItems.MOD_ID, value = Dist.CLIENT)
public final class InventoryOverlay {
    private static boolean trashMode;
    private static SidePanel panel;
    private static Screen panelScreen;

    private InventoryOverlay() {}

    @SubscribeEvent
    public static void onInit(ScreenEvent.Init.Post event) {
        panel = null;
        panelScreen = null;
        Screen screen = event.getScreen();
        if (!(screen instanceof AbstractContainerScreen<?> container)
                || screen instanceof CreativeModeInventoryScreen) {
            return;
        }
        Font font = Minecraft.getInstance().font;

        // ---- top toolbar ----
        int x = 4;
        x = addToolbarButton(event, font, x, "T", "Trash mode: click inventory slots to delete them (Creative)", button -> {
            trashMode = !trashMode;
            button.setMessage(trashLabel());
        }, trashLabel());
        x = addToolbarButton(event, font, x, "S", "Survival mode", b -> command("gamemode survival"), null);
        x = addToolbarButton(event, font, x, "C", "Creative mode", b -> command("gamemode creative"), null);
        x = addToolbarButton(event, font, x, "A", "Adventure mode", b -> command("gamemode adventure"), null);
        x = addToolbarButton(event, font, x, "Rain", "Make it rain", b -> command("weather rain"), null);
        x = addToolbarButton(event, font, x, "Sun", "Clear weather", b -> command("weather clear"), null);
        x = addToolbarButton(event, font, x, "Day", "Set time to day", b -> command("time set day"), null);
        x = addToolbarButton(event, font, x, "Night", "Set time to night", b -> command("time set night"), null);
        addToolbarButton(event, font, x, "Heal", "Restore health and hunger", b -> {
            command("effect give @s minecraft:instant_health 1 10 true");
            command("effect give @s minecraft:saturation 1 10 true");
        }, null);

        // ---- save slots on the left ----
        for (int i = 1; i <= SaveSlots.COUNT; i++) {
            final int slot = i;
            Button button = Button.builder(saveLabel(slot), b -> {
                if (Screen.hasShiftDown() || !SaveSlots.exists(slot)) SaveSlots.save(slot);
                else SaveSlots.load(slot);
                b.setMessage(saveLabel(slot));
            }).bounds(4, 30 + (i - 1) * 22, 46, 20)
              .tooltip(Tooltip.create(Component.literal(
                      "Empty: click to save. Saved: click to load, Shift+click to overwrite.")))
              .build();
            event.addListener(button);
        }

        // ---- item list on the right ----
        int panelX = container.getGuiLeft() + container.getXSize() + 8;
        int cols = Math.min(12, (screen.width - panelX - 4) / 18);
        int rows = Math.max(1, Math.min(16, (screen.height - 28 - 34) / 18));
        if (cols >= 3) {
            panel = new SidePanel(font, panelX, 28, cols, rows);
            panelScreen = screen;
            event.addListener(panel);
        }
    }

    private static int addToolbarButton(ScreenEvent.Init.Post event, Font font, int x, String label,
                                        String tooltip, Button.OnPress action, Component styled) {
        Component text = styled != null ? styled : Component.literal(label);
        int width = font.width(label) + 10;
        Button button = Button.builder(text, action)
                .bounds(x, 4, width, 20)
                .tooltip(Tooltip.create(Component.literal(tooltip)))
                .build();
        event.addListener(button);
        return x + width + 2;
    }

    private static Component trashLabel() {
        return Component.literal("T").withStyle(trashMode ? ChatFormatting.RED : ChatFormatting.WHITE);
    }

    private static Component saveLabel(int slot) {
        return Component.literal((SaveSlots.exists(slot) ? "Load " : "Save ") + slot);
    }

    private static void command(String command) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null && player.connection != null) {
            player.connection.sendCommand(command);
        }
    }

    @SubscribeEvent
    public static void onRenderPost(ScreenEvent.Render.Post event) {
        if (panel != null && event.getScreen() == panelScreen) {
            panel.renderLate(event.getGuiGraphics(), event.getMouseX(), event.getMouseY());
        }
    }

    @SubscribeEvent
    public static void onMousePressed(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!trashMode || event.getButton() != 0
                || !(event.getScreen() instanceof InventoryScreen screen)) {
            return;
        }
        Slot slot = screen.getSlotUnderMouse();
        if (slot == null || !slot.hasItem() || slot.index < 5 || slot.index > 45) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getAbilities().instabuild && mc.gameMode != null) {
            slot.set(ItemStack.EMPTY);
            mc.gameMode.handleCreativeModeItemAdd(ItemStack.EMPTY, slot.index);
        } else {
            ItemGiver.message("Trash mode needs Creative mode");
        }
        event.setCanceled(true);
    }
}
