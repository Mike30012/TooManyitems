package de.example.toomanyitems.client;

import de.example.toomanyitems.TooManyItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Adds the classic TMI overlay (toolbar, save slots, item list) to inventory/container screens. */
@EventBusSubscriber(modid = TooManyItems.MOD_ID, value = Dist.CLIENT)
public final class InventoryOverlay {
    private static boolean trashMode;
    private static SidePanel panel;
    private static Screen panelScreen;

    private InventoryOverlay() {}

    @SubscribeEvent
    public static void onInit(ScreenEvent.Init.Post event) {
        panel = null;
        panelScreen = null;
        Screen screen = event.getScreen();
        if (!(screen instanceof AbstractContainerScreen<?> container)) {
            return;
        }
        Font font = Minecraft.getInstance().font;

        // ---- top toolbar (same order as the classic TMI bar) ----
        int x = 2;
        if (screen instanceof InventoryScreen) { // trash mode only works on the normal inventory
            x = addIcon(event, IconButton.toggle(x, Icons.TRASH,
                    "Trash mode: click inventory slots to delete them (Creative)",
                    () -> trashMode = !trashMode, () -> trashMode, 0xFF8A2A2A));
        }
        x = addIcon(event, IconButton.letter(x, "S", "Survival mode",
                () -> command("gamemode survival"), () -> isMode(GameType.SURVIVAL)));
        x = addIcon(event, IconButton.letter(x, "C", "Creative mode",
                () -> command("gamemode creative"), () -> isMode(GameType.CREATIVE)));
        x = addIcon(event, IconButton.letter(x, "A", "Adventure mode",
                () -> command("gamemode adventure"), () -> isMode(GameType.ADVENTURE)));
        x = addIcon(event, IconButton.toggle(x, Icons.RAIN, "Toggle rain",
                () -> command(isRaining() ? "weather clear" : "weather rain"),
                InventoryOverlay::isRaining, 0xFF2F4F9A));
        x = addIcon(event, IconButton.icon(x, Icons.SUNRISE, "Time: sunrise", () -> command("time set 23000")));
        x = addIcon(event, IconButton.icon(x, Icons.SUN, "Time: noon", () -> command("time set 6000")));
        x = addIcon(event, IconButton.icon(x, Icons.DUSK, "Time: sunset", () -> command("time set 12500")));
        x = addIcon(event, IconButton.icon(x, Icons.MIDNIGHT, "Time: midnight", () -> command("time set 18000")));
        addIcon(event, IconButton.icon(x, Icons.HEART, "Restore health and hunger", () -> {
            command("effect give @s minecraft:instant_health 1 10 true");
            command("effect give @s minecraft:saturation 1 10 true");
        }));

        // ---- save slots on the left ----
        for (int i = 1; i <= SaveSlots.COUNT; i++) {
            final int slot = i;
            Button button = Button.builder(saveLabel(slot), b -> {
                if (Screen.hasShiftDown() || !SaveSlots.exists(slot)) SaveSlots.save(slot);
                else SaveSlots.load(slot);
                b.setMessage(saveLabel(slot));
            }).bounds(4, 30 + (i - 1) * 22, 46, 20)
              .tooltip(Tooltip.create(Component.literal(
                      "Empty: click to save. Saved: click to load, Shift+click to overwrite.")))
              .build();
            event.addListener(button);
        }

        // ---- item list on the right ----
        int panelX = container.getGuiLeft() + container.getXSize() + 8;
        int cols = Math.min(12, (screen.width - panelX - 4) / 18);
        int rows = Math.max(1, Math.min(16, (screen.height - 86) / 18));
        if (cols >= 3) {
            panel = new SidePanel(font, panelX, 28, cols, rows);
            panelScreen = screen;
            event.addListener(panel);
        }
    }

    /** Adds the button and returns the x position for the next one. */
    private static int addIcon(ScreenEvent.Init.Post event, IconButton button) {
        event.addListener(button);
        return button.getX() + IconButton.SIZE + 2;
    }

    private static boolean isMode(GameType type) {
        Minecraft mc = Minecraft.getInstance();
        return mc.gameMode != null && mc.gameMode.getPlayerMode() == type;
    }

    private static boolean isRaining() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level != null && mc.level.isRaining();
    }

    private static Component saveLabel(int slot) {
        return Component.literal((SaveSlots.exists(slot) ? "Load " : "Save ") + slot);
    }

    private static void command(String command) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null && player.connection != null) {
            player.connection.sendCommand(command);
        }
    }

    @SubscribeEvent
    public static void onRenderPost(ScreenEvent.Render.Post event) {
        if (panel != null && event.getScreen() == panelScreen) {
            panel.renderLate(event.getGuiGraphics(), event.getMouseX(), event.getMouseY());
        }
    }

    @SubscribeEvent
    public static void onKeyPressed(ScreenEvent.KeyPressed.Pre event) {
        if (panel != null && event.getScreen() == panelScreen
                && panel.handleKey(event.getKeyCode(), event.getScanCode(), event.getModifiers())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onCharTyped(ScreenEvent.CharacterTyped.Pre event) {
        if (panel != null && event.getScreen() == panelScreen
                && panel.handleChar(event.getCodePoint(), event.getModifiers())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onMousePressed(ScreenEvent.MouseButtonPressed.Pre event) {
        if (!trashMode || event.getButton() != 0
                || !(event.getScreen() instanceof InventoryScreen screen)) {
            return;
        }
        Slot slot = screen.getSlotUnderMouse();
        if (slot == null || !slot.hasItem() || slot.index < 5 || slot.index > 45) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.getAbilities().instabuild && mc.gameMode != null) {
            slot.set(ItemStack.EMPTY);
            mc.gameMode.handleCreativeModeItemAdd(ItemStack.EMPTY, slot.index);
        } else {
            ItemGiver.message("Trash mode needs Creative mode");
        }
        event.setCanceled(true);
    }
}
