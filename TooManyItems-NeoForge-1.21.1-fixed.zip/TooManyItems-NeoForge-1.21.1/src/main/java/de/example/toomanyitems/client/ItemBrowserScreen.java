package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ItemBrowserScreen extends Screen {
    private static final int COLUMNS = 9;
    private static final int ROWS = 6;
    private static final int SLOT_SIZE = 20;
    private static final int PANEL_WIDTH = COLUMNS * SLOT_SIZE + 20;
    private static final int PANEL_HEIGHT = 174;

    private final List<Item> allItems = new ArrayList<>();
    private final List<Item> visibleItems = new ArrayList<>();
    private EditBox search;
    private String lastQuery = "";
    /** Index of the first visible row (scrolls row by row). */
    private int scroll;

    public ItemBrowserScreen() {
        super(Component.literal("TooManyItems"));
        BuiltInRegistries.ITEM.stream()
                .filter(item -> item != Items.AIR)
                .forEach(allItems::add);
        allItems.sort((a, b) -> BuiltInRegistries.ITEM.getKey(a).toString()
                .compareToIgnoreCase(BuiltInRegistries.ITEM.getKey(b).toString()));
        filterItems("");
    }

    private int panelLeft() {
        return (width - PANEL_WIDTH) / 2;
    }

    private int panelTop() {
        return height / 2 - 125;
    }

    private int maxScroll() {
        int totalRows = (visibleItems.size() + COLUMNS - 1) / COLUMNS;
        return Math.max(0, totalRows - ROWS);
    }

    @Override
    protected void init() {
        int left = panelLeft();
        int top = panelTop();
        // init() runs again on window resize: keep the text the player already typed.
        search = new EditBox(font, left + 10, top + 13, PANEL_WIDTH - 20, 18,
                Component.literal("Search items"));
        search.setHint(Component.literal("Search items..."));
        search.setValue(lastQuery);
        search.setResponder(value -> {
            lastQuery = value;
            scroll = 0;
            filterItems(value);
        });
        addRenderableWidget(search);
        setInitialFocus(search);
    }

    private void filterItems(String rawQuery) {
        String query = rawQuery.toLowerCase(Locale.ROOT).trim();
        visibleItems.clear();
        for (Item item : allItems) {
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getDescription().getString().toLowerCase(Locale.ROOT);
            if (query.isEmpty() || id.contains(query) || name.contains(query)) {
                visibleItems.add(item);
            }
        }
        scroll = Math.min(scroll, maxScroll());
    }

    /**
     * Since 1.21, Screen#render already calls renderBackground itself. Calling it a second time
     * crashes ("Can only blur once per frame"), so the panel is drawn from here instead.
     */
    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(graphics, mouseX, mouseY, partialTick);
        int left = panelLeft();
        int top = panelTop();
        graphics.fill(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xE0101018);
        graphics.renderOutline(left, top, PANEL_WIDTH, PANEL_HEIGHT, 0xFF777777);
        graphics.drawCenteredString(font, "TooManyItems", width / 2, top + 3, 0xFFFFFF);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick); // background, panel, search box

        int gridX = panelLeft() + 10;
        int gridY = panelTop() + 43;
        int start = scroll * COLUMNS;
        ItemStack hovered = ItemStack.EMPTY;
        int hoveredX = 0;
        int hoveredY = 0;

        for (int slot = 0; slot < COLUMNS * ROWS; slot++) {
            int x = gridX + (slot % COLUMNS) * SLOT_SIZE;
            int y = gridY + (slot / COLUMNS) * SLOT_SIZE;
            graphics.fill(x, y, x + 18, y + 18, 0x80505050);
            int index = start + slot;
            if (index < visibleItems.size()) {
                ItemStack stack = new ItemStack(visibleItems.get(index));
                graphics.renderItem(stack, x + 1, y + 1);
                if (mouseX >= x && mouseX < x + 18 && mouseY >= y && mouseY < y + 18) {
                    hovered = stack;
                    hoveredX = mouseX;
                    hoveredY = mouseY;
                }
            }
        }

        int total = visibleItems.size();
        int first = total == 0 ? 0 : start + 1;
        int last = Math.min(total, start + COLUMNS * ROWS);
        graphics.drawCenteredString(font, first + "-" + last + " / " + total,
                width / 2, panelTop() + 163, 0xCCCCCC);

        // Draw the tooltip last so later slots cannot paint over it.
        if (!hovered.isEmpty()) {
            graphics.renderTooltip(font, hovered, hoveredX, hoveredY);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button != 0 || minecraft == null || minecraft.player == null
                || minecraft.gameMode == null) return false;

        int gridX = panelLeft() + 10;
        int gridY = panelTop() + 43;
        if (mouseX < gridX || mouseY < gridY
                || mouseX >= gridX + COLUMNS * SLOT_SIZE
                || mouseY >= gridY + ROWS * SLOT_SIZE) {
            return false;
        }
        int col = (int) ((mouseX - gridX) / SLOT_SIZE);
        int row = (int) ((mouseY - gridY) / SLOT_SIZE);
        int index = (scroll + row) * COLUMNS + col;
        if (index >= visibleItems.size()) return false;

        ItemGiver.give(minecraft, visibleItems.get(index), true);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(deltaY)));
        return true;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
