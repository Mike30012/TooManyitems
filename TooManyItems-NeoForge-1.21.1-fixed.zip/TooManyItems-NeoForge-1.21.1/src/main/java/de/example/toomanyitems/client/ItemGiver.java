package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Gives items to the player: directly in Creative, via /give otherwise. */
final class ItemGiver {
    private ItemGiver() {}

    /** Maps a player-inventory index (0-35 main, 36-39 armor feet..head, 40 offhand) to the inventory menu slot. */
    static int menuSlot(int inventoryIndex) {
        if (inventoryIndex < 9) return 36 + inventoryIndex;   // hotbar
        if (inventoryIndex < 36) return inventoryIndex;       // main inventory
        if (inventoryIndex < 40) return 44 - inventoryIndex;  // feet(36)->8, legs->7, chest->6, head(39)->5
        return 45;                                            // offhand
    }

    static void give(Minecraft mc, Item item, boolean fullStack) {
        LocalPlayer player = mc.player;
        if (player == null) return;

        ItemStack stack = new ItemStack(item);
        stack.setCount(fullStack ? stack.getMaxStackSize() : 1);

        if (player.getAbilities().instabuild && mc.gameMode != null) {
            Inventory inventory = player.getInventory();
            int target = inventory.getFreeSlot();
            if (target < 0) target = inventory.selected; // inventory full: replace the held slot
            inventory.setItem(target, stack.copy());
            mc.gameMode.handleCreativeModeItemAdd(stack, menuSlot(target));
        } else if (player.connection != null) {
            player.connection.sendCommand("give @s " + BuiltInRegistries.ITEM.getKey(item) + " " + stack.getCount());
        }
    }

    static void message(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) player.displayClientMessage(Component.literal(text), true);
    }
}
