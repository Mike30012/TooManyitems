package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.Map;
import java.util.Optional;
import java.util.StringJoiner;

/** Gives items to the player: directly in Creative, via /give otherwise. */
final class ItemGiver {
    private ItemGiver() {}

    /** Maps a player-inventory index (0-35 main, 36-39 armor feet..head, 40 offhand) to the inventory menu slot. */
    static int menuSlot(int inventoryIndex) {
        if (inventoryIndex < 9) return 36 + inventoryIndex;   // hotbar
        if (inventoryIndex < 36) return inventoryIndex;       // main inventory
        if (inventoryIndex < 40) return 44 - inventoryIndex;  // feet(36)->8, legs->7, chest->6, head(39)->5
        return 45;                                            // offhand
    }

    static void give(Minecraft mc, Item item, boolean fullStack) {
        give(mc, new ItemStack(item), fullStack);
    }

    static void give(Minecraft mc, ItemStack template, boolean fullStack) {
        LocalPlayer player = mc.player;
        if (player == null) return;

        ItemStack stack = template.copy();
        stack.setCount(fullStack ? stack.getMaxStackSize() : 1);

        if (player.getAbilities().instabuild && mc.gameMode != null) {
            Inventory inventory = player.getInventory();
            int target = inventory.getFreeSlot();
            if (target < 0) target = inventory.selected; // inventory full: replace the held slot
            inventory.setItem(target, stack.copy());
            mc.gameMode.handleCreativeModeItemAdd(stack, menuSlot(target));
        } else if (player.connection != null) {
            player.connection.sendCommand("give @s " + commandItem(mc, stack) + " " + stack.getCount());
        }
    }

    /** "minecraft:potion[potion_contents={...}]": the item id plus its data components as SNBT. */
    private static String commandItem(Minecraft mc, ItemStack stack) {
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        DataComponentPatch patch = stack.getComponentsPatch();
        if (patch.isEmpty() || mc.level == null) return id;
        RegistryOps<Tag> ops = mc.level.registryAccess().createSerializationContext(NbtOps.INSTANCE);
        StringJoiner components = new StringJoiner(",", "[", "]");
        for (Map.Entry<DataComponentType<?>, Optional<?>> entry : patch.entrySet()) {
            ResourceLocation key = BuiltInRegistries.DATA_COMPONENT_TYPE.getKey(entry.getKey());
            if (key == null) continue;
            if (entry.getValue().isEmpty()) {
                components.add("!" + key);
            } else {
                components.add(key + "=" + encode(ops, entry.getKey(), entry.getValue().get()));
            }
        }
        return id + components;
    }

    @SuppressWarnings("unchecked")
    private static <T> Tag encode(RegistryOps<Tag> ops, DataComponentType<?> type, Object value) {
        return ((DataComponentType<T>) type).codecOrThrow().encodeStart(ops, (T) value).getOrThrow();
    }

    static void message(String text) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player != null) player.displayClientMessage(Component.literal(text), true);
    }
}
