package de.example.toomanyitems.client;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Sorted list of all registered items plus the search filter shared by all item lists. */
final class ItemIndex {
    private static List<Item> all;

    private ItemIndex() {}

    static List<Item> all() {
        if (all == null) {
            List<Item> list = new ArrayList<>();
            BuiltInRegistries.ITEM.stream().filter(item -> item != Items.AIR).forEach(list::add);
            list.sort((a, b) -> BuiltInRegistries.ITEM.getKey(a).toString()
                    .compareToIgnoreCase(BuiltInRegistries.ITEM.getKey(b).toString()));
            all = list;
        }
        return all;
    }

    static List<Item> filter(String rawQuery) {
        String query = rawQuery.toLowerCase(Locale.ROOT).trim();
        if (query.isEmpty()) return all();
        List<Item> result = new ArrayList<>();
        for (Item item : all()) {
            String id = BuiltInRegistries.ITEM.getKey(item).toString().toLowerCase(Locale.ROOT);
            String name = item.getDescription().getString().toLowerCase(Locale.ROOT);
            if (id.contains(query) || name.contains(query)) result.add(item);
        }
        return result;
    }
}
