package de.example.toomanyitems.client;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.RegistryAccess;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** "Save 1-7": stores the whole player inventory (incl. armor and offhand) in a file. */
final class SaveSlots {
    static final int COUNT = 7;
    private static final int SLOTS = 41; // 36 main + 4 armor + offhand
    private static final Logger LOGGER = LogUtils.getLogger();

    private SaveSlots() {}

    private static Path file(int slot) {
        return Minecraft.getInstance().gameDirectory.toPath()
                .resolve("toomanyitems").resolve("inventory_" + slot + ".dat");
    }

    static boolean exists(int slot) {
        return Files.exists(file(slot));
    }

    static void save(int slot) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;
        RegistryOps<Tag> ops = mc.level.registryAccess().createSerializationContext(NbtOps.INSTANCE);
        Inventory inventory = player.getInventory();
        CompoundTag root = new CompoundTag();
        for (int i = 0; i < SLOTS; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!stack.isEmpty()) {
                root.put("s" + i, ItemStack.CODEC.encodeStart(ops, stack).getOrThrow());
            }
        }
        try {
            Path path = file(slot);
            Files.createDirectories(path.getParent());
            NbtIo.writeCompressed(root, path);
            ItemGiver.message("Inventory saved to slot " + slot);
        } catch (IOException | RuntimeException e) {
            LOGGER.error("Could not save inventory slot {}", slot, e);
            ItemGiver.message("Saving failed (see log)");
        }
    }

    static void load(int slot) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.gameMode == null) return;
        if (!player.getAbilities().instabuild) {
            ItemGiver.message("Loading inventories needs Creative mode");
            return;
        }
        try {
            CompoundTag root = NbtIo.readCompressed(file(slot), NbtAccounter.unlimitedHeap());
            RegistryAccess access = mc.level.registryAccess();
            RegistryOps<Tag> ops = access.createSerializationContext(NbtOps.INSTANCE);
            Inventory inventory = player.getInventory();
            for (int i = 0; i < SLOTS; i++) {
                ItemStack stack = ItemStack.EMPTY;
                if (root.contains("s" + i)) {
                    stack = ItemStack.CODEC.parse(ops, root.get("s" + i)).result().orElse(ItemStack.EMPTY);
                }
                inventory.setItem(i, stack);
                mc.gameMode.handleCreativeModeItemAdd(stack, ItemGiver.menuSlot(i));
            }
            ItemGiver.message("Inventory loaded from slot " + slot);
        } catch (IOException | RuntimeException e) {
            LOGGER.error("Could not load inventory slot {}", slot, e);
            ItemGiver.message("Loading failed (see log)");
        }
    }
}
