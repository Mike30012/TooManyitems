package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** The item list docked to the right of the inventory: search box, item grid, page arrows. */
final class SidePanel extends AbstractWidget {
    private static final int CELL = 18;
    private static final int GRID_OFFSET = 20;

    // Static so the search text and scroll position survive the screen being rebuilt (window resize).
    private static String query = "";
    private static int scroll = 0;

    private final Font font;
    private final EditBox search;
    private final int cols;
    private final int rows;
    private List<Item> items;

    SidePanel(Font font, int x, int y, int cols, int rows) {
        super(x, y, cols * CELL, GRID_OFFSET + rows * CELL + 14, Component.literal("TooManyItems"));
        this.font = font;
        this.cols = cols;
        this.rows = rows;
        this.items = ItemIndex.filter(query);
        this.search = new EditBox(font, x + 1, y, cols * CELL - 2, 16, Component.literal("Search items"));
        search.setHint(Component.literal("Search..."));
        search.setValue(query);
        search.setResponder(value -> {
            query = value;
            scroll = 0;
            items = ItemIndex.filter(value);
        });
        clampScroll();
    }

    private int maxScroll() {
        int totalRows = (items.size() + cols - 1) / cols;
        return Math.max(0, totalRows - rows);
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
    }

    private int gridY() {
        return getY() + GRID_OFFSET;
    }

    private int labelY() {
        return gridY() + rows * CELL + 3;
    }

    private Item itemAt(double mouseX, double mouseY) {
        if (mouseX < getX() || mouseY < gridY()
                || mouseX >= getX() + cols * CELL || mouseY >= gridY() + rows * CELL) return null;
        int col = (int) ((mouseX - getX()) / CELL);
        int row = (int) ((mouseY - gridY()) / CELL);
        int index = (scroll + row) * cols + col;
        return index < items.size() ? items.get(index) : null;
    }

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(getX() - 2, getY() - 2, getX() + width + 2, getY() + height + 2, 0x70000000);
        search.render(graphics, mouseX, mouseY, partialTick);

        Item hovered = itemAt(mouseX, mouseY);
        int start = scroll * cols;
        for (int slot = 0; slot < cols * rows; slot++) {
            int x = getX() + (slot % cols) * CELL;
            int y = gridY() + (slot / cols) * CELL;
            graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80404040);
            int index = start + slot;
            if (index < items.size()) {
                Item item = items.get(index);
                graphics.renderItem(new ItemStack(item), x + 1, y + 1);
                if (item == hovered) {
                    graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80FFFFFF);
                }
            }
        }

        int total = items.size();
        int first = total == 0 ? 0 : start + 1;
        int last = Math.min(total, start + cols * rows);
        graphics.drawString(font, "<", getX() + 3, labelY(), 0xFFFFFF);
        graphics.drawString(font, ">", getX() + width - 9, labelY(), 0xFFFFFF);
        graphics.drawCenteredString(font, first + "-" + last + " / " + total,
                getX() + width / 2, labelY(), 0xCCCCCC);
    }

    /** Called after the whole screen is drawn so the tooltip is not painted over. */
    void renderLate(GuiGraphics graphics, int mouseX, int mouseY) {
        Item hovered = itemAt(mouseX, mouseY);
        if (hovered != null) {
            graphics.renderTooltip(font, new ItemStack(hovered), mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isMouseOver(mouseX, mouseY)) {
            search.setFocused(false);
            return false;
        }
        if (mouseY < getY() + 17) {
            search.setFocused(true);
            if (button == 1) search.setValue(""); // right click clears the search
            else search.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        search.setFocused(false);

        Item item = itemAt(mouseX, mouseY);
        if (item != null) {
            ItemGiver.give(Minecraft.getInstance(), item, button == 0);
            return true;
        }
        if (mouseY >= labelY() - 2) {
            if (mouseX < getX() + 20) scroll -= rows;
            else if (mouseX > getX() + width - 20) scroll += rows;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        scroll -= (int) Math.signum(scrollY);
        clampScroll();
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (search.isFocused()) {
            search.keyPressed(keyCode, scanCode, modifiers);
            // Swallow every key (so "E" does not close the inventory) except Escape.
            return keyCode != 256;
        }
        return false;
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        return search.isFocused() && search.charTyped(codePoint, modifiers);
    }

    @Override
    public void setFocused(boolean focused) {
        super.setFocused(focused);
        if (!focused) search.setFocused(false);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, getMessage());
    }
}
