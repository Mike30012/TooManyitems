package de.example.toomanyitems.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The panel docked to the right of the inventory: tabs, search box, item grid, page arrows. */
final class SidePanel extends AbstractWidget {
    private static final int CELL = 18;
    private static final int TAB_HEIGHT = 18;
    private static final int SEARCH_Y = 20;
    private static final int GRID_OFFSET = 40;

    // Static so the tab, search text and scroll position survive the screen being rebuilt (window resize).
    private static String query = "";
    private static int scroll = 0;
    private static ItemIndex.Tab tab = ItemIndex.Tab.ITEMS;

    private final Font font;
    private final EditBox search;
    private final int cols;
    private final int rows;
    private final ItemStack[] tabIcons = new ItemStack[ItemIndex.Tab.values().length];
    private List<ItemIndex.Entry> base;
    private List<ItemIndex.Entry> entries = new ArrayList<>();
    private ItemIndex.Entry hovered;

    SidePanel(Font font, int x, int y, int cols, int rows) {
        super(x, y, cols * CELL, GRID_OFFSET + rows * CELL + 14, Component.literal("TooManyItems"));
        this.font = font;
        this.cols = cols;
        this.rows = rows;

        tabIcons[ItemIndex.Tab.ITEMS.ordinal()] = new ItemStack(Items.CRAFTING_TABLE);
        tabIcons[ItemIndex.Tab.ENCHANTS.ordinal()] = new ItemStack(Items.ENCHANTED_BOOK);
        tabIcons[ItemIndex.Tab.POTIONS.ordinal()] = PotionContents.createItemStack(Items.POTION, Potions.HEALING);
        tabIcons[ItemIndex.Tab.FIREWORKS.ordinal()] = new ItemStack(Items.FIREWORK_ROCKET);

        this.search = new EditBox(font, x + 1, y + SEARCH_Y, cols * CELL - 2, 16, Component.literal("Search items"));
        search.setHint(Component.literal("Search..."));
        search.setValue(query);
        search.setResponder(value -> {
            query = value;
            scroll = 0;
            applyFilter();
        });
        this.base = ItemIndex.entries(tab);
        applyFilter();
    }

    // ---------------------------------------------------------------- data

    private void applyFilter() {
        String needle = query.toLowerCase(Locale.ROOT).trim();
        if (needle.isEmpty()) {
            entries = base;
        } else {
            List<ItemIndex.Entry> filtered = new ArrayList<>();
            for (ItemIndex.Entry entry : base) {
                if (entry.search().contains(needle)) filtered.add(entry);
            }
            entries = filtered;
        }
        clampScroll();
    }

    private void setTab(ItemIndex.Tab newTab) {
        tab = newTab;
        scroll = 0;
        base = ItemIndex.entries(newTab);
        applyFilter();
    }

    private int maxScroll() {
        int totalRows = (entries.size() + cols - 1) / cols;
        return Math.max(0, totalRows - rows);
    }

    private void clampScroll() {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
    }

    private boolean canFavorite() {
        return tab == ItemIndex.Tab.ITEMS || tab == ItemIndex.Tab.FAVORITES;
    }

    private void toggleFavorite(ItemIndex.Entry entry) {
        boolean added = Favorites.toggle(BuiltInRegistries.ITEM.getKey(entry.stack().getItem()));
        ItemGiver.message(added ? "Added to favorites" : "Removed from favorites");
        if (tab == ItemIndex.Tab.FAVORITES) {
            base = ItemIndex.entries(tab);
            applyFilter();
        }
    }

    // ---------------------------------------------------------------- geometry

    private int gridY() {
        return getY() + GRID_OFFSET;
    }

    private int labelY() {
        return gridY() + rows * CELL + 3;
    }

    private int tabWidth() {
        return width / ItemIndex.Tab.values().length;
    }

    private int tabAt(double mouseX, double mouseY) {
        if (mouseY < getY() || mouseY >= getY() + TAB_HEIGHT || mouseX < getX() || mouseX >= getX() + width) return -1;
        return Math.min(ItemIndex.Tab.values().length - 1, (int) ((mouseX - getX()) / tabWidth()));
    }

    private ItemIndex.Entry entryAt(double mouseX, double mouseY) {
        if (mouseX < getX() || mouseY < gridY()
                || mouseX >= getX() + cols * CELL || mouseY >= gridY() + rows * CELL) return null;
        int col = (int) ((mouseX - getX()) / CELL);
        int row = (int) ((mouseY - gridY()) / CELL);
        int index = (scroll + row) * cols + col;
        return index < entries.size() ? entries.get(index) : null;
    }

    // ---------------------------------------------------------------- rendering

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(getX() - 2, getY() - 2, getX() + width + 2, getY() + height + 2, 0x70000000);

        renderTabs(graphics, mouseX, mouseY);
        search.render(graphics, mouseX, mouseY, partialTick);

        hovered = entryAt(mouseX, mouseY);
        int start = scroll * cols;
        for (int slot = 0; slot < cols * rows; slot++) {
            int x = getX() + (slot % cols) * CELL;
            int y = gridY() + (slot / cols) * CELL;
            graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80404040);
            int index = start + slot;
            if (index < entries.size()) {
                ItemIndex.Entry entry = entries.get(index);
                graphics.renderItem(entry.stack(), x + 1, y + 1);
                if (entry == hovered) {
                    graphics.fill(x, y, x + CELL - 1, y + CELL - 1, 0x80FFFFFF);
                }
                if (canFavorite() && Favorites.contains(BuiltInRegistries.ITEM.getKey(entry.stack().getItem()))) {
                    graphics.pose().pushPose();
                    graphics.pose().translate(0, 0, 200); // above the item model
                    Icons.draw(graphics, Icons.STAR_SMALL, x + CELL - 7, y - 1);
                    graphics.pose().popPose();
                }
            }
        }

        int total = entries.size();
        int first = total == 0 ? 0 : start + 1;
        int last = Math.min(total, start + cols * rows);
        graphics.drawString(font, "<", getX() + 3, labelY(), 0xFFFFFF);
        graphics.drawString(font, ">", getX() + width - 9, labelY(), 0xFFFFFF);
        graphics.drawCenteredString(font, first + "-" + last + " / " + total,
                getX() + width / 2, labelY(), 0xCCCCCC);
    }

    private void renderTabs(GuiGraphics graphics, int mouseX, int mouseY) {
        ItemIndex.Tab[] tabs = ItemIndex.Tab.values();
        int tabWidth = tabWidth();
        int hoveredTab = tabAt(mouseX, mouseY);
        for (int i = 0; i < tabs.length; i++) {
            int x = getX() + i * tabWidth;
            int y = getY();
            int w = tabWidth - 2;
            int h = TAB_HEIGHT - 2;
            int face = tabs[i] == tab ? 0xFF3C5A8A : (i == hoveredTab ? 0xFF58606E : 0xFF353B47);
            graphics.fill(x, y, x + w, y + h, 0xFF0E0E10);
            graphics.fill(x + 1, y + 1, x + w - 1, y + h - 1, face);
            graphics.fill(x + 1, y + 1, x + w - 1, y + 2, 0x40FFFFFF);
            if (tabs[i] == ItemIndex.Tab.FAVORITES) {
                Icons.draw(graphics, Icons.STAR, x + (w - Icons.SIZE) / 2, y + (h - Icons.SIZE) / 2);
            } else {
                graphics.renderItem(tabIcons[i], x + (w - 16) / 2, y + (h - 16) / 2);
            }
        }
    }

    /** Called after the whole screen is drawn so tooltips are not painted over. */
    void renderLate(GuiGraphics graphics, int mouseX, int mouseY) {
        int tabIndex = tabAt(mouseX, mouseY);
        if (tabIndex >= 0) {
            graphics.renderTooltip(font, Component.literal(ItemIndex.Tab.values()[tabIndex].title), mouseX, mouseY);
            return;
        }
        ItemIndex.Entry entry = entryAt(mouseX, mouseY);
        if (entry != null) {
            List<Component> lines = Screen.getTooltipFromItem(Minecraft.getInstance(), entry.stack());
            graphics.renderTooltip(font, lines, entry.stack().getTooltipImage(), mouseX, mouseY);
        }
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isMouseOver(mouseX, mouseY)) {
            search.setFocused(false);
            return false;
        }

        int tabIndex = tabAt(mouseX, mouseY);
        if (tabIndex >= 0) {
            search.setFocused(false);
            setTab(ItemIndex.Tab.values()[tabIndex]);
            return true;
        }

        if (mouseY >= getY() + SEARCH_Y && mouseY < getY() + SEARCH_Y + 17) {
            search.setFocused(true);
            if (button == 1) search.setValue(""); // right click clears the search
            else search.mouseClicked(mouseX, mouseY, button);
            return true;
        }
        search.setFocused(false);

        ItemIndex.Entry entry = entryAt(mouseX, mouseY);
        if (entry != null) {
            if (button == 0 && Screen.hasShiftDown() && canFavorite()) {
                toggleFavorite(entry);
            } else {
                ItemGiver.give(Minecraft.getInstance(), entry.stack(), button == 0);
            }
            return true;
        }
        if (mouseY >= labelY() - 2) {
            if (mouseX < getX() + 20) scroll -= rows;
            else if (mouseX > getX() + width - 20) scroll += rows;
            clampScroll();
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        scroll -= (int) Math.signum(scrollY);
        clampScroll();
        return true;
    }

    /**
     * Key/char forwarding. InventoryOverlay calls these from screen events (before the screen sees the
     * key), because e.g. the Creative inventory ignores typed characters in most tabs and uses "T" to
     * jump to its own search tab.
     */
    boolean handleKey(int keyCode, int scanCode, int modifiers) {
        if (!search.isFocused()) {
            // "F" over an item toggles its favorite star (handy where Shift is hard to press).
            if (keyCode == GLFW.GLFW_KEY_F && hovered != null && canFavorite()) {
                toggleFavorite(hovered);
                return true;
            }
            return false;
        }
        if (keyCode == 256) return false; // let Escape close the screen
        search.keyPressed(keyCode, scanCode, modifiers);
        return true; // swallow every other key so "E" does not close the inventory
    }

    boolean handleChar(char codePoint, int modifiers) {
        if (!search.isFocused()) return false;
        search.charTyped(codePoint, modifiers);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return handleKey(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        return handleChar(codePoint, modifiers);
    }

    @Override
    public void setFocused(boolean focused) {
        super.setFocused(focused);
        if (!focused) search.setFocused(false);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, getMessage());
    }
}
