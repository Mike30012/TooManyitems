# TooManyItems 2 (NeoForge 1.21.1)
Item-Browser, Taste O. Tabs: Items, Meine, Spezial (Item bearbeiten, Trank, Feuerwerk, Kopf, Schild, Lederfarbe, Notenblock, Spawner), Zauber, Steuerung, Saves.
