package dev.itembrowser;

import net.minecraft.client.Minecraft;

import java.util.ArrayDeque;
import java.util.Deque;

/** Schickt viele Befehle nacheinander (wenige pro Tick), damit der Server nicht wegen Spam kickt. */
public final class CommandQueue {
	private static final Deque<String> QUEUE = new ArrayDeque<>();

	private CommandQueue() {}

	public static void add(String cmd) {
		QUEUE.add(cmd);
	}

	public static void tick(Minecraft mc) {
		if (mc.player == null) {
			QUEUE.clear();
			return;
		}
		for (int i = 0; i < 4 && !QUEUE.isEmpty(); i++) {
			mc.player.connection.sendCommand(QUEUE.poll());
		}
	}
}
