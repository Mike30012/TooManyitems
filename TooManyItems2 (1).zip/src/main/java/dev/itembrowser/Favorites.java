package dev.itembrowser;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** "Meine Items" - wird in config/itembrowser.json gespeichert. */
public final class Favorites {
	private static final List<String> IDS = new ArrayList<>();

	private Favorites() {}

	private static Path file() {
		return FMLPaths.CONFIGDIR.get().resolve("itembrowser.json");
	}

	public static void load() {
		IDS.clear();
		try {
			Path f = file();
			if (Files.exists(f)) {
				JsonArray arr = JsonParser.parseString(Files.readString(f)).getAsJsonArray();
				arr.forEach(e -> IDS.add(e.getAsString()));
			}
		} catch (Exception ignored) {
		}
	}

	private static void save() {
		try {
			JsonArray arr = new JsonArray();
			IDS.forEach(arr::add);
			Files.writeString(file(), arr.toString());
		} catch (Exception ignored) {
		}
	}

	public static List<Item> items() {
		List<Item> out = new ArrayList<>();
		for (String s : IDS) {
			ResourceLocation id = ResourceLocation.tryParse(s);
			if (id == null) continue;
			BuiltInRegistries.ITEM.getOptional(id).ifPresent(out::add);
		}
		return out;
	}

	private static String idOf(Item item) {
		return BuiltInRegistries.ITEM.getKey(item).toString();
	}

	public static boolean has(Item item) {
		return IDS.contains(idOf(item));
	}

	public static void toggle(Item item) {
		String id = idOf(item);
		if (!IDS.remove(id)) IDS.add(id);
		save();
	}

	public static void remove(Item item) {
		IDS.remove(idOf(item));
		save();
	}
}
