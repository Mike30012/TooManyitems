package dev.itembrowser;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

@Mod(value = ItemBrowser.MODID, dist = Dist.CLIENT)
public class ItemBrowser {
	public static final String MODID = "itembrowser";

	public static final KeyMapping OPEN = new KeyMapping(
			"key.itembrowser.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, "key.categories.itembrowser");

	public ItemBrowser(IEventBus modBus, ModContainer container) {
		Favorites.load();
		Saves.load();
		modBus.addListener(this::registerKeys);
		NeoForge.EVENT_BUS.addListener(this::onTick);
		NeoForge.EVENT_BUS.addListener(this::onInventoryKey);
	}

	private void registerKeys(RegisterKeyMappingsEvent event) {
		event.register(OPEN);
	}

	// Taste O im Spiel
	private void onTick(ClientTickEvent.Post event) {
		Minecraft mc = Minecraft.getInstance();
		CommandQueue.tick(mc);
		while (OPEN.consumeClick()) {
			if (mc.screen == null && mc.player != null) {
				mc.setScreen(new ItemScreen());
			}
		}
	}

	// Taste O im normalen Inventar (nicht wenn das Rezeptbuch offen ist, wegen der Suche)
	private void onInventoryKey(ScreenEvent.KeyPressed.Post event) {
		if (event.getScreen() instanceof InventoryScreen inv
				&& !(event.getScreen() instanceof ItemScreen)
				&& !inv.getRecipeBookComponent().isVisible()
				&& OPEN.matches(event.getKeyCode(), event.getScanCode())) {
			Minecraft.getInstance().setScreen(new ItemScreen());
		}
	}
}
