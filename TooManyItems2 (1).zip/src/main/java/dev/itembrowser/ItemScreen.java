package dev.itembrowser;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class ItemScreen extends InventoryScreen {
	private static final int T_ITEMS = 0, T_FAV = 1, T_SPECIAL = 2, T_ENCH = 3, T_CTRL = 4, T_SAVES = 5;
	private static final String[] TAB_NAMES = {"Items", "Meine", "Spezial", "Zauber", "Steuerung"};
	private static final int[] AMOUNTS = {1, 16, 64, -1}; // -1 = voller Stack

	private static final String[] POTION_ITEMS = {"potion", "splash_potion", "lingering_potion", "tipped_arrow"};
	private static final String[] POTION_NAMES = {"Trank", "Wurftrank", "Verweiltrank", "Pfeil"};
	private static final String[] SHAPES = {"small_ball", "large_ball", "star", "creeper", "burst"};
	private static final String[] SIGNS = {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "bamboo", "crimson", "warped"};
	private static final String[] LEATHER = {"leather_helmet", "leather_chestplate", "leather_leggings", "leather_boots", "leather_horse_armor"};
	private static final String[] LEATHER_NAMES = {"Helm", "Brustplatte", "Hose", "Schuhe", "Pferderuestung"};
	private static final int[] DYES = {0xF9FFFE, 0xF9801D, 0xC74EBD, 0x3AB3DA, 0xFED83D, 0x80C71F, 0xF38BAA, 0x474F52,
			0x9D9D97, 0x169C9C, 0x8932B8, 0x3C44AA, 0x835432, 0x5E7C16, 0xB02E26, 0x1D1D21};

	// bleibt beim erneuten Oeffnen erhalten
	private static int tab = T_ITEMS;
	private static int sub = 0;
	private static int amountIdx = 2;
	private static String query = "";
	private static final Map<String, Integer> ENCH_LEVELS = new LinkedHashMap<>();
	private static final Map<String, Integer> EFFECT_LEVELS = new LinkedHashMap<>();
	private static String editName = "", editLore = "";
	private static boolean editUnbreakable = false;
	private static int potionType = 0;
	private static String potionSec = "60";
	private static int fwShape = 1, fwFlight = 1;
	private static String fwColors = "ff0000", fwFade = "";
	private static boolean fwTrail = false, fwTwinkle = false;
	private static String headName = "";
	private static int signType = 0;
	private static final String[] signLines = {"", "", "", ""};
	private static int leatherType = 1;
	private static String leatherHex = "a06540";
	private static int note = 0;
	private static String saveName = "";

	private static List<Item> ALL;
	private static final Map<Item, String> NAMES = new HashMap<>();

	private record Entry(String id, int max) {}

	private record Row(Component label, int max, String key, Map<String, Integer> map, int y) {}

	private int page = 0;
	private EditBox search;
	private EditBox leatherBox;
	private List<Item> shown = new ArrayList<>();
	private final List<Row> rows = new ArrayList<>();
	private final List<Object[]> labels = new ArrayList<>(); // {text, x, y, color}
	private final List<int[]> swatches = new ArrayList<>();  // {x, y, color}
	private String levelPrefix = "";

	private boolean gridMode, showPager;
	private int listRows = 1, listSize = 0;
	private int px, py, pw, ph;
	private int gridX, gridY, cols, gridRows;

	public ItemScreen() {
		super(Minecraft.getInstance().player);
	}

	// Im Creative-Modus wuerde InventoryScreen sich sonst selbst ersetzen
	public void containerTick() {
		if (minecraft != null && minecraft.gameMode != null && !minecraft.gameMode.hasInfiniteItems()) {
			super.containerTick();
		}
	}

	// ------------------------------------------------------------------ Daten

	private static List<Item> all() {
		if (ALL == null) {
			List<Item> l = new ArrayList<>();
			for (Item i : BuiltInRegistries.ITEM) {
				if (i != Items.AIR) l.add(i);
			}
			ALL = l;
		}
		return ALL;
	}

	private static String nameOf(Item i) {
		return NAMES.computeIfAbsent(i, it -> it.getDescription().getString().toLowerCase(Locale.ROOT));
	}

	private void refilter() {
		String q = query.toLowerCase(Locale.ROOT).trim();
		List<Item> src = tab == T_FAV ? Favorites.items() : all();
		List<Item> out = new ArrayList<>();
		for (Item i : src) {
			if (q.isEmpty() || nameOf(i).contains(q) || BuiltInRegistries.ITEM.getKey(i).toString().contains(q)) {
				out.add(i);
			}
		}
		shown = out;
	}

	private List<Entry> enchantEntries() {
		List<Entry> l = new ArrayList<>();
		if (minecraft != null && minecraft.level != null) {
			var reg = minecraft.level.registryAccess().registryOrThrow(Registries.ENCHANTMENT);
			for (var e : reg.entrySet()) {
				l.add(new Entry(e.getKey().location().toString(), e.getValue().getMaxLevel()));
			}
			l.sort(Comparator.comparing(Entry::id));
		}
		return l;
	}

	private List<Entry> effectEntries() {
		List<Entry> l = new ArrayList<>();
		for (ResourceLocation id : BuiltInRegistries.MOB_EFFECT.keySet()) {
			l.add(new Entry(id.toString(), -1));
		}
		l.sort(Comparator.comparing(Entry::id));
		return l;
	}

	// ------------------------------------------------------------------ Helfer fuer Widgets

	private Button btn(String text, int x, int y, int w, int h, Runnable r) {
		IconButton b = new IconButton(x, y, w, h, null, text, r);
		addRenderableWidget(b);
		return b;
	}

	private EditBox box(int x, int y, int w, String val, Consumer<String> onChange) {
		EditBox e = new EditBox(font, x, y, w, 16, Component.empty());
		e.setMaxLength(200);
		e.setValue(val);
		e.setResponder(onChange);
		addRenderableWidget(e);
		return e;
	}

	private void label(String text, int x, int y) {
		labels.add(new Object[]{text, x, y, 0xFFB0A0FF});
	}

	private void cycle(int x, int y, int w, String prefix, String[] names, IntSupplier get, IntConsumer set) {
		IconButton[] ref = new IconButton[1];
		ref[0] = new IconButton(x, y, w, 16, null, prefix + names[get.getAsInt()], () -> {
			set.accept((get.getAsInt() + 1) % names.length);
			ref[0].setMessage(Component.literal(prefix + names[get.getAsInt()]));
		});
		addRenderableWidget(ref[0]);
	}

	private void toggle(int x, int y, int w, String text, BooleanSupplier get, Consumer<Boolean> set) {
		IconButton[] ref = new IconButton[1];
		ref[0] = new IconButton(x, y, w, 16, null, text + (get.getAsBoolean() ? "Ja" : "Nein"), () -> {
			set.accept(!get.getAsBoolean());
			ref[0].setMessage(Component.literal(text + (get.getAsBoolean() ? "Ja" : "Nein")));
		});
		addRenderableWidget(ref[0]);
	}

	private void msg(String text) {
		if (minecraft != null && minecraft.player != null) {
			minecraft.player.displayClientMessage(Component.literal(text), true);
		}
	}

	private ItemStack held() {
		return minecraft != null && minecraft.player != null ? minecraft.player.getMainHandItem() : ItemStack.EMPTY;
	}

	private void run(String cmd) {
		if (minecraft != null && minecraft.player != null) {
			minecraft.player.connection.sendCommand(cmd);
		}
	}

	private void giveSpec(String spec) {
		run("give @s " + spec);
	}

	private String idOf(Item it) {
		return BuiltInRegistries.ITEM.getKey(it).toString();
	}

	// ------------------------------------------------------------------ Aufbau

	@Override
	protected void init() {
		super.init();
		pw = Math.min(300, Math.max(200, width * 2 / 5));
		ph = height - 4;
		px = width - pw - 2;
		py = 2;
		labels.clear();
		rows.clear();
		swatches.clear();
		search = null;
		leatherBox = null;
		showPager = false;
		gridMode = tab == T_ITEMS || tab == T_FAV;

		// Reiter oben rechts (Icons)
		Item[] tabIcons = {Items.CHEST, Items.NETHER_STAR, Items.POTION, Items.ENCHANTED_BOOK, Items.COMMAND_BLOCK};
		String[] tabTips = {"Items", "Meine Items", "Spezial (Trank, Feuerwerk, ...)", "Zauber", "Steuerung"};
		for (int i = 0; i < tabIcons.length; i++) {
			final int idx = i;
			IconButton b = new IconButton(px + 6 + i * 26, py + 4, 22, 22, new ItemStack(tabIcons[i]), null, () -> {
				tab = idx;
				page = 0;
				rebuildWidgets();
			});
			b.selected = tab == i;
			b.setTooltip(Tooltip.create(Component.literal(tabTips[i])));
			addRenderableWidget(b);
		}

		initQuickBar();

		// Saves links (wie im echten TMI): Klick = laden (oder speichern, wenn leer), Shift+Klick = speichern
		List<String> existing = Saves.names();
		for (int i = 1; i <= 7; i++) {
			final String nm = "Save " + i;
			btn(nm + (existing.contains(nm) ? " *" : ""), 0, 24 + (i - 1) * 22, 56, 20, () -> {
				if (hasShiftDown() || !Saves.names().contains(nm)) {
					Saves.saveCurrent(nm);
					msg("Gespeichert: " + nm);
				} else {
					Saves.loadInto(nm);
					msg("Lade: " + nm);
				}
				rebuildWidgets();
			});
		}
		label("Klick: laden", 2, 24 + 7 * 22 + 2);
		label("Shift: speichern", 2, 24 + 7 * 22 + 12);

		switch (tab) {
			case T_ITEMS, T_FAV -> initGrid();
			case T_SPECIAL -> initSpecial();
			case T_ENCH -> initEnchant();
			case T_CTRL -> initControls();
			case T_SAVES -> initSaves();
			default -> {}
		}
		if (showPager) addPager();
	}

	// ---- Schnellleiste oben links (Gamemode, Wetter, Zeit, Heilen ...)

	private void quick(int i, Item icon, String text, String tip, Runnable r) {
		IconButton b = new IconButton(2 + i * 16, 2, 14, 14, icon == null ? null : new ItemStack(icon), text, r);
		b.setTooltip(Tooltip.create(Component.literal(tip)));
		addRenderableWidget(b);
	}

	private void initQuickBar() {
		quick(0, Items.BARRIER, null, "Inventar leeren", () -> run("clear @s"));
		quick(1, null, "S", "Survival", () -> run("gamemode survival"));
		quick(2, null, "C", "Creative", () -> run("gamemode creative"));
		quick(3, null, "A", "Abenteuer", () -> run("gamemode adventure"));
		quick(4, Items.WATER_BUCKET, null, "Wetter: Klick = klar, Shift = Regen",
				() -> run(hasShiftDown() ? "weather rain" : "weather clear"));
		quick(5, Items.SUNFLOWER, null, "Tag", () -> run("time set day"));
		quick(6, Items.CLOCK, null, "Nacht", () -> run("time set night"));
		quick(7, Items.CREEPER_HEAD, null, "Mobs: Klick = aus, Shift = an",
				() -> run("gamerule doMobSpawning " + (hasShiftDown() ? "true" : "false")));
		quick(8, Items.GOLDEN_APPLE, null, "Heilen", () -> {
			run("effect give @s minecraft:instant_health 1 20 true");
			run("effect give @s minecraft:saturation 1 20 true");
		});
	}

	// Schlichter dunkler Knopf (wie im TMI): Icon und/oder Text
	private static class IconButton extends Button {
		private final ItemStack icon;
		boolean selected;

		IconButton(int x, int y, int w, int h, ItemStack icon, String text, Runnable r) {
			super(x, y, w, h, Component.literal(text == null ? "" : text), b -> r.run(), DEFAULT_NARRATION);
			this.icon = icon;
		}

		@Override
		protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float delta) {
			int bg = isHoveredOrFocused() ? 0xFF606060 : (selected ? 0xFF404040 : 0xE0000000);
			g.fill(getX(), getY(), getX() + width, getY() + height, bg);
			if (selected) g.renderOutline(getX(), getY(), width, height, 0xFFFFFFFF);
			Minecraft mc = Minecraft.getInstance();
			if (icon != null) {
				float sc = height >= 20 ? 1.0f : 0.75f;
				g.pose().pushPose();
				g.pose().translate(getX() + (width - 16 * sc) / 2f, getY() + (height - 16 * sc) / 2f, 0);
				g.pose().scale(sc, sc, 1f);
				g.renderItem(icon, 0, 0);
				g.pose().popPose();
			}
			if (!getMessage().getString().isEmpty()) {
				g.drawCenteredString(mc.font, getMessage(), getX() + width / 2, getY() + (height - 8) / 2, 0xFFFFFFFF);
			}
		}
	}

	// ---- Items / Meine Items

	private void initGrid() {
		int top = py + 30;
		search = new EditBox(font, px + 6, top, pw - 12 - 50, 16, Component.literal("Suche"));
		search.setMaxLength(64);
		search.setValue(query);
		search.setSuggestion(query.isEmpty() ? "Suchen..." : null);
		search.setResponder(s -> {
			query = s;
			page = 0;
			search.setSuggestion(s.isEmpty() ? "Suchen..." : null);
			refilter();
		});
		addRenderableWidget(search);

		gridX = px + 6;
		gridY = top + 26;
		cols = Math.max(1, (pw - 12) / 18);
		gridRows = Math.max(1, (py + ph - 28 - gridY) / 18);
		refilter();
		showPager = true;

		IconButton[] amt = new IconButton[1];
		amt[0] = new IconButton(px + pw - 92, py + ph - 22, 86, 16, null, amountText().getString(), () -> {
			amountIdx = (amountIdx + 1) % AMOUNTS.length;
			amt[0].setMessage(amountText());
		});
		addRenderableWidget(amt[0]);
	}

	private Component amountText() {
		int a = AMOUNTS[amountIdx];
		return Component.literal("Menge: " + (a < 0 ? "Stack" : String.valueOf(a)));
	}

	// ---- Seiten

	private void addPager() {
		int by = gridMode ? py + 30 : py + ph - 22;
		int x1 = gridMode ? px + pw - 46 : px + 6;
		int x2 = gridMode ? px + pw - 24 : px + 28;
		btn("<", x1, by, 20, 16, () -> {
			if (page > 0) {
				page--;
				pageChanged();
			}
		});
		btn(">", x2, by, 20, 16, () -> {
			if (page < pageCount() - 1) {
				page++;
				pageChanged();
			}
		});
	}

	private void pageChanged() {
		if (!gridMode) rebuildWidgets();
	}

	private int perPage() {
		return gridMode ? Math.max(1, cols * gridRows) : Math.max(1, listRows);
	}

	private int total() {
		return gridMode ? shown.size() : listSize;
	}

	private int pageCount() {
		return Math.max(1, (total() + perPage() - 1) / perPage());
	}

	// ---- Liste mit Level-Reglern (Verzauberungen / Traenke)

	private void initLevelList(int top, int bottom, List<Entry> entries, Map<String, Integer> map, String prefix) {
		levelPrefix = prefix;
		listRows = Math.max(1, (bottom - top) / 20);
		listSize = entries.size();
		showPager = true;
		page = Math.min(page, pageCount() - 1);
		for (int i = 0; i < listRows; i++) {
			int idx = page * listRows + i;
			if (idx >= entries.size()) break;
			final Entry e = entries.get(idx);
			int y = top + i * 20;
			rows.add(new Row(null, e.max(), e.id(), map, y));
			btn("-", px + pw - 74, y, 20, 18, () -> change(map, e.id(), hasShiftDown() ? -5 : -1));
			btn("+", px + pw - 26, y, 20, 18, () -> change(map, e.id(), hasShiftDown() ? 5 : 1));
		}
	}

	private void change(Map<String, Integer> map, String id, int delta) {
		int v = Math.max(0, Math.min(255, map.getOrDefault(id, 0) + delta));
		if (v == 0) map.remove(id);
		else map.put(id, v);
		rebuildWidgets();
	}

	// ---- Verzaubern

	private void initEnchant() {
		initLevelList(py + 54, py + ph - 46, enchantEntries(), ENCH_LEVELS, "enchantment.");
		int half = (pw - 12 - 3) / 2;
		btn("Verzauberte Kopie geben", px + 6, py + ph - 42, half, 18, this::giveEnchanted);
		btn("Zuruecksetzen", px + 6 + half + 3, py + ph - 42, half, 18, () -> {
			ENCH_LEVELS.clear();
			rebuildWidgets();
		});
	}

	private void giveEnchanted() {
		ItemStack h = held();
		if (h.isEmpty()) {
			msg("Halte ein Item in der Haupthand.");
			return;
		}
		if (ENCH_LEVELS.isEmpty()) {
			msg("Stelle erst Verzauberungen mit + ein.");
			return;
		}
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, Integer> en : ENCH_LEVELS.entrySet()) {
			if (sb.length() > 0) sb.append(',');
			sb.append('"').append(en.getKey()).append("\":").append(en.getValue());
		}
		Map<String, String> o = new LinkedHashMap<>();
		o.put("enchantments", "{levels:{" + sb + "}}");
		giveSpec(StackUtil.spec(h, o, 1));
	}

	// ---- Steuerung

	private void initControls() {
		int y = py + 32;
		section("Spielmodus", y, new String[][]{
				{"Survival", "gamemode survival"}, {"Creative", "gamemode creative"},
				{"Abenteuer", "gamemode adventure"}, {"Zuschauer", "gamemode spectator"}});
		y += 34;
		section("Zeit", y, new String[][]{
				{"Tag", "time set day"}, {"Mittag", "time set noon"},
				{"Nacht", "time set night"}, {"Mitternacht", "time set midnight"}});
		y += 34;
		section("Wetter", y, new String[][]{
				{"Klar", "weather clear"}, {"Regen", "weather rain"}, {"Gewitter", "weather thunder"}});
		y += 34;
		section("Schwierigkeit", y, new String[][]{
				{"Friedlich", "difficulty peaceful"}, {"Leicht", "difficulty easy"},
				{"Normal", "difficulty normal"}, {"Schwer", "difficulty hard"}});
		y += 34;
		section("Spieler", y, new String[][]{
				{"Heilen", "effect give @s minecraft:instant_health 1 20 true|effect give @s minecraft:saturation 1 20 true"},
				{"Effekte weg", "effect clear @s"},
				{"Inv. leeren", "clear @s"},
				{"Drops weg", "kill @e[type=minecraft:item]"}});
		y += 34;
		section("Spielregeln", y, new String[][]{
				{"KeepInv an", "gamerule keepInventory true"}, {"KeepInv aus", "gamerule keepInventory false"},
				{"Mobs aus", "gamerule doMobSpawning false"}, {"Mobs an", "gamerule doMobSpawning true"}});
	}

	private void section(String title, int y, String[][] entries) {
		label(title, px + 8, y);
		int n = entries.length;
		int gap = 3;
		int w = (pw - 12 - (n - 1) * gap) / n;
		for (int i = 0; i < n; i++) {
			final String cmd = entries[i][1];
			btn(entries[i][0], px + 6 + i * (w + gap), y + 11, w, 18, () -> {
				for (String c : cmd.split("\\|")) run(c);
			});
		}
	}

	// ---- Saves

	private void initSaves() {
		int top = py + 30;
		box(px + 6, top, pw - 100, saveName, s -> saveName = s);
		btn("Inventar speichern", px + pw - 90, top - 1, 84, 18, () -> {
			if (Saves.saveCurrent(saveName)) {
				msg("Gespeichert: " + saveName.trim());
				rebuildWidgets();
			} else {
				msg("Gib erst einen Namen ein.");
			}
		});
		label("Gespeichertes Inventar:", px + 8, top + 22);

		List<String> names = Saves.names();
		int rtop = top + 34;
		listRows = Math.max(1, (py + ph - 26 - rtop) / 20);
		listSize = names.size();
		showPager = true;
		page = Math.min(page, pageCount() - 1);
		for (int i = 0; i < listRows; i++) {
			int idx = page * listRows + i;
			if (idx >= names.size()) break;
			final String nm = names.get(idx);
			int y = rtop + i * 20;
			rows.add(new Row(Component.literal(nm), -1, null, null, y));
			btn("Laden", px + pw - 86, y, 50, 18, () -> {
				Saves.loadInto(nm);
				msg("Lade: " + nm);
			});
			btn("X", px + pw - 32, y, 26, 18, () -> {
				Saves.remove(nm);
				rebuildWidgets();
			});
		}
	}

	// ---- Spezial-Menue

	private void initSpecial() {
		if (sub == 0) {
			String[] n = {"Item bearbeiten", "Trank", "Feuerwerk", "Kopf", "Schild", "Lederfarbe", "Notenblock", "Spawner"};
			int w = (pw - 12 - 4) / 2;
			for (int i = 0; i < n.length; i++) {
				final int s = i + 1;
				btn(n[i], px + 6 + (i % 2) * (w + 4), py + 34 + (i / 2) * 26, w, 22, () -> {
					sub = s;
					page = 0;
					rebuildWidgets();
				});
			}
			return;
		}
		btn("< Zurueck", px + 6, py + 30, 70, 16, () -> {
			sub = 0;
			page = 0;
			rebuildWidgets();
		});
		String[] titles = {"", "Item bearbeiten", "Trank", "Feuerwerk", "Kopf", "Schild", "Lederfarbe", "Notenblock", "Spawner"};
		label(titles[sub], px + 84, py + 34);
		switch (sub) {
			case 1 -> initEdit();
			case 2 -> initPotion();
			case 3 -> initFirework();
			case 4 -> initHead();
			case 5 -> initSign();
			case 6 -> initLeather();
			case 7 -> initNote();
			case 8 -> initSpawner();
			default -> {}
		}
	}

	private void giveButton(Runnable r) {
		btn("Geben", px + 6, py + ph - 42, pw - 12, 18, r);
	}

	// Item bearbeiten
	private void initEdit() {
		int top = py + 54;
		label("Name (&c = Farbe, z.B. &cRot):", px + 8, top);
		box(px + 6, top + 10, pw - 12, editName, s -> editName = s);
		label("Lore (Zeilen mit | trennen):", px + 8, top + 32);
		box(px + 6, top + 42, pw - 12, editLore, s -> editLore = s);
		toggle(px + 6, top + 66, 150, "Unzerbrechlich: ", () -> editUnbreakable, v -> editUnbreakable = v);
		label("Wirkt auf das Item in der Haupthand (als Kopie).", px + 8, top + 90);
		giveButton(() -> {
			ItemStack h = held();
			if (h.isEmpty()) {
				msg("Halte ein Item in der Haupthand.");
				return;
			}
			Map<String, String> o = new LinkedHashMap<>();
			if (!editName.isBlank()) o.put("custom_name", StackUtil.snbt(StackUtil.json(editName)));
			if (!editLore.isBlank()) {
				StringBuilder sb = new StringBuilder("[");
				String[] lines = editLore.split("\\|");
				for (int i = 0; i < lines.length; i++) {
					if (i > 0) sb.append(',');
					sb.append(StackUtil.snbt(StackUtil.json(lines[i])));
				}
				o.put("lore", sb.append(']').toString());
			}
			if (editUnbreakable) o.put("unbreakable", "{}");
			giveSpec(StackUtil.spec(h, o, h.getCount()));
		});
	}

	// Trank
	private void initPotion() {
		int top = py + 52;
		cycle(px + 6, top, 110, "", POTION_NAMES, () -> potionType, v -> potionType = v);
		label("Dauer (Sek.):", px + 124, top + 4);
		box(px + 200, top, 50, potionSec, s -> potionSec = s);
		initLevelList(top + 22, py + ph - 46, effectEntries(), EFFECT_LEVELS, "effect.");
		giveButton(() -> {
			if (EFFECT_LEVELS.isEmpty()) {
				msg("Stelle erst Effekte mit + ein.");
				return;
			}
			int sec = 60;
			try {
				sec = Math.max(1, Integer.parseInt(potionSec.trim()));
			} catch (NumberFormatException ignored) {
			}
			StringBuilder sb = new StringBuilder();
			for (Map.Entry<String, Integer> en : EFFECT_LEVELS.entrySet()) {
				if (sb.length() > 0) sb.append(',');
				sb.append("{id:\"").append(en.getKey()).append("\",amplifier:").append(en.getValue() - 1)
						.append(",duration:").append(sec * 20).append('}');
			}
			giveSpec("minecraft:" + POTION_ITEMS[potionType] + "[potion_contents={custom_effects:[" + sb + "]}] 1");
		});
	}

	// Feuerwerk
	private void initFirework() {
		int top = py + 54;
		int half = (pw - 12 - 3) / 2;
		cycle(px + 6, top, half, "Form: ", SHAPES, () -> fwShape, v -> fwShape = v);
		cycle(px + 9 + half, top, half, "Flugdauer: ", new String[]{"1", "2", "3"}, () -> fwFlight - 1, v -> fwFlight = v + 1);
		label("Farben (Hex, Komma getrennt):", px + 8, top + 22);
		box(px + 6, top + 32, pw - 12, fwColors, s -> fwColors = s);
		label("Ausblenden zu (Hex, optional):", px + 8, top + 54);
		box(px + 6, top + 64, pw - 12, fwFade, s -> fwFade = s);
		toggle(px + 6, top + 88, half, "Spur: ", () -> fwTrail, v -> fwTrail = v);
		toggle(px + 9 + half, top + 88, half, "Funkeln: ", () -> fwTwinkle, v -> fwTwinkle = v);
		giveButton(() -> giveSpec("minecraft:firework_rocket[fireworks={flight_duration:" + fwFlight
				+ ",explosions:[{shape:\"" + SHAPES[fwShape] + "\",colors:[" + StackUtil.colorArray(fwColors, 0xFF0000)
				+ "],fade_colors:[" + StackUtil.colorArray(fwFade, -1) + "],has_trail:" + fwTrail
				+ ",has_twinkle:" + fwTwinkle + "}]}] 1"));
	}

	// Kopf
	private void initHead() {
		int top = py + 54;
		label("Spielername:", px + 8, top);
		box(px + 6, top + 10, pw - 12, headName, s -> headName = s);
		giveButton(() -> {
			String n = headName.trim();
			if (!n.matches("[A-Za-z0-9_]{1,16}")) {
				msg("Ungueltiger Spielername.");
				return;
			}
			giveSpec("minecraft:player_head[profile=\"" + n + "\"] 1");
		});
	}

	// Schild
	private void initSign() {
		int top = py + 54;
		cycle(px + 6, top, 150, "Holz: ", SIGNS, () -> signType, v -> signType = v);
		for (int i = 0; i < 4; i++) {
			final int li = i;
			label("Zeile " + (i + 1) + ":", px + 8, top + 24 + i * 24);
			box(px + 60, top + 20 + i * 24, pw - 66, signLines[i], s -> signLines[li] = s);
		}
		giveButton(() -> {
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < 4; i++) {
				if (i > 0) sb.append(',');
				sb.append(StackUtil.snbt(StackUtil.json(signLines[i])));
			}
			giveSpec("minecraft:" + SIGNS[signType] + "_sign[block_entity_data={id:\"minecraft:sign\",front_text:{messages:["
					+ sb + "]}}] 1");
		});
	}

	// Lederfarbe
	private void initLeather() {
		int top = py + 54;
		cycle(px + 6, top, 170, "Teil: ", LEATHER_NAMES, () -> leatherType, v -> leatherType = v);
		label("Farbe (Hex):", px + 8, top + 26);
		leatherBox = box(px + 80, top + 22, 70, leatherHex, s -> leatherHex = s);
		for (int i = 0; i < DYES.length; i++) {
			final int c = DYES[i];
			int x = px + 6 + (i % 8) * 24;
			int y = top + 48 + (i / 8) * 20;
			Button b = Button.builder(Component.empty(), bb -> {
				leatherHex = String.format("%06x", c);
				leatherBox.setValue(leatherHex);
			}).bounds(x, y, 22, 18).build();
			addRenderableWidget(b);
			swatches.add(new int[]{x, y, c});
		}
		giveButton(() -> giveSpec("minecraft:" + LEATHER[leatherType] + "[dyed_color={rgb:"
				+ StackUtil.parseHex(leatherHex, 0xA06540) + "}] 1"));
	}

	// Notenblock
	private void initNote() {
		int top = py + 58;
		label("Ton (0-24):", px + 8, top + 4);
		btn("-", px + 90, top, 20, 18, () -> {
			note = Math.max(0, note - 1);
			rebuildWidgets();
		});
		label(String.valueOf(note), px + 118, top + 4);
		btn("+", px + 140, top, 20, 18, () -> {
			note = Math.min(24, note + 1);
			rebuildWidgets();
		});
		giveButton(() -> giveSpec("minecraft:note_block[block_state={note:\"" + note + "\"}] 1"));
	}

	// Spawner
	private void initSpawner() {
		List<EntityType<?>> types = new ArrayList<>();
		for (EntityType<?> t : BuiltInRegistries.ENTITY_TYPE) {
			if (t.canSummon()) types.add(t);
		}
		types.sort(Comparator.comparing(t -> BuiltInRegistries.ENTITY_TYPE.getKey(t).toString()));
		int top = py + 52;
		listRows = Math.max(1, (py + ph - 26 - top) / 20);
		listSize = types.size();
		showPager = true;
		page = Math.min(page, pageCount() - 1);
		for (int i = 0; i < listRows; i++) {
			int idx = page * listRows + i;
			if (idx >= types.size()) break;
			EntityType<?> t = types.get(idx);
			String id = BuiltInRegistries.ENTITY_TYPE.getKey(t).toString();
			btn(t.getDescription().getString() + "  (" + id + ")", px + 6, top + i * 20, pw - 12, 18, () ->
					giveSpec("minecraft:spawner[block_entity_data={id:\"minecraft:mob_spawner\",SpawnData:{entity:{id:\""
							+ id + "\"}}}] 1"));
		}
	}

	// ------------------------------------------------------------------ Befehle

	private void give(Item it, boolean single) {
		int a = AMOUNTS[amountIdx];
		int count = single ? 1 : (a < 0 ? it.getDefaultMaxStackSize() : a);
		run("give @s " + idOf(it) + " " + count);
	}

	// ------------------------------------------------------------------ Rendern

	@Override
	public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) {
		super.renderBackground(g, mouseX, mouseY, delta);
		g.fill(px, py, px + pw, py + ph, 0x70000000);
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
		super.render(g, mouseX, mouseY, delta);

		if (showPager) {
			page = Math.min(page, pageCount() - 1);
			if (gridMode) {
				g.drawCenteredString(font, Component.literal((page + 1) + "/" + pageCount()),
						px + pw - 24, py + 48, 0xFFFFFFFF);
			} else {
				g.drawCenteredString(font,
						Component.literal((page + 1) + "/" + pageCount() + "  (" + total() + ")"),
						px + pw / 2 - 20, py + ph - 18, 0xFFFFFFFF);
			}
		}
		for (Object[] l : labels) {
			g.drawString(font, (String) l[0], (Integer) l[1], (Integer) l[2], (Integer) l[3], false);
		}
		for (int[] s : swatches) {
			g.fill(s[0] + 2, s[1] + 2, s[0] + 20, s[1] + 16, 0xFF000000 | s[2]);
		}
		if (tab == T_SPECIAL && sub == 6 && leatherBox != null) {
			int c = StackUtil.parseHex(leatherHex, 0xA06540);
			g.fill(px + 160, py + 54 + 22, px + 176, py + 54 + 38, 0xFFFFFFFF);
			g.fill(px + 161, py + 54 + 23, px + 175, py + 54 + 37, 0xFF000000 | c);
		}

		switch (tab) {
			case T_ITEMS, T_FAV -> renderGrid(g, mouseX, mouseY);
			case T_ENCH -> {
				ItemStack h = held();
				if (h.isEmpty()) {
					g.drawString(font, "Halte ein Item in der Hand, das verzaubert werden soll.", px + 8, py + 34, 0xFFFFAA55, false);
				} else {
					g.renderItem(h, px + 8, py + 30);
					g.drawString(font, h.getHoverName(), px + 28, py + 34, 0xFFFFFFFF, false);
				}
				renderRows(g);
			}
			default -> renderRows(g);
		}
	}

	private void renderRows(GuiGraphics g) {
		for (Row r : rows) {
			Component name = r.label();
			if (name == null) {
				ResourceLocation id = ResourceLocation.tryParse(r.key());
				name = id == null ? Component.literal(r.key())
						: Component.translatable(levelPrefix + id.getNamespace() + "." + id.getPath());
			}
			g.drawString(font, name, px + 8, r.y() + 5, 0xFFFFFFFF, false);
			if (r.map() != null) {
				if (r.max() > 0) {
					g.drawString(font, "max " + r.max(), px + pw - 150, r.y() + 5, 0xFF888888, false);
				}
				int lvl = r.map().getOrDefault(r.key(), 0);
				g.drawCenteredString(font, Component.literal(String.valueOf(lvl)),
						px + pw - 50, r.y() + 5, lvl > 0 ? 0xFF55FF55 : 0xFFAAAAAA);
			}
		}
	}

	private void renderGrid(GuiGraphics g, int mouseX, int mouseY) {
		int per = cols * gridRows;
		Item hover = null;
		for (int i = 0; i < per; i++) {
			int idx = page * per + i;
			if (idx >= shown.size()) break;
			int x = gridX + (i % cols) * 18;
			int y = gridY + (i / cols) * 18;
			Item it = shown.get(idx);
			boolean h = mouseX >= x && mouseX < x + 18 && mouseY >= y && mouseY < y + 18;
			if (h) {
				g.fill(x, y, x + 17, y + 17, 0x80FFFFFF);
				hover = it;
			}
			g.renderItem(new ItemStack(it), x + 1, y + 1);
			if (tab == T_ITEMS && Favorites.has(it)) {
				g.drawString(font, "*", x + 11, y + 1, 0xFFFFD700, true);
			}
		}
		if (shown.isEmpty()) {
			g.drawString(font,
					tab == T_FAV ? "Noch leer - im Items-Tab Rechtsklick auf ein Item." : "Nichts gefunden.",
					gridX + 2, gridY + 4, 0xFF999999, false);
		}
		if (hover != null) {
			ItemStack st = new ItemStack(hover);
			List<Component> tip = new ArrayList<>(Screen.getTooltipFromItem(minecraft, st));
			tip.add(Component.literal("Links: geben | Shift+Links: 1 Stueck").withStyle(ChatFormatting.GRAY));
			tip.add(Component.literal(tab == T_ITEMS ? "Rechts: zu Meine Items" : "Rechts: entfernen")
					.withStyle(ChatFormatting.GRAY));
			g.renderComponentTooltip(font, tip, mouseX, mouseY);
		}
	}

	// ------------------------------------------------------------------ Eingaben

	private Item itemAt(double mx, double my) {
		if (mx < gridX || my < gridY) return null;
		int cx = (int) ((mx - gridX) / 18);
		int cy = (int) ((my - gridY) / 18);
		if (cx >= cols || cy >= gridRows) return null;
		int idx = page * cols * gridRows + cy * cols + cx;
		return idx < shown.size() ? shown.get(idx) : null;
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		boolean mine = (mouseX >= px && mouseX <= px + pw && mouseY >= py && mouseY <= py + ph) || mouseX < 60;
		if (!mine) return super.mouseClicked(mouseX, mouseY, button);
		for (var l : children()) {
			if (l.mouseClicked(mouseX, mouseY, button)) {
				setFocused(l);
				return true;
			}
		}
		setFocused(null);
		if (gridMode) {
			Item it = itemAt(mouseX, mouseY);
			if (it != null) {
				if (button == 0) {
					give(it, hasShiftDown());
				} else if (button == 1) {
					if (tab == T_ITEMS) {
						Favorites.toggle(it);
					} else {
						Favorites.remove(it);
						refilter();
					}
				}
			}
		}
		return true;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (showPager && mouseX >= px) {
			int np = page - (int) Math.signum(scrollY);
			np = Math.max(0, Math.min(pageCount() - 1, np));
			if (np != page) {
				page = np;
				pageChanged();
			}
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		boolean typing = getFocused() instanceof EditBox e && e.isFocused();
		if (typing) {
			if (keyCode == 256) return super.keyPressed(keyCode, scanCode, modifiers); // ESC
			getFocused().keyPressed(keyCode, scanCode, modifiers);
			return true;
		}
		if (ItemBrowser.OPEN.matches(keyCode, scanCode)) {
			onClose();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
