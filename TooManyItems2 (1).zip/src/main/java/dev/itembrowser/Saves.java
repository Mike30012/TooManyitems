package dev.itembrowser;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.loading.FMLPaths;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Inventar-Speicherstaende in config/itembrowser-saves.json (Eintrag = "slot<TAB>item-text"). */
public final class Saves {
	private static final Map<String, List<String>> DATA = new LinkedHashMap<>();

	private Saves() {}

	private static Path file() {
		return FMLPaths.CONFIGDIR.get().resolve("itembrowser-saves.json");
	}

	public static void load() {
		DATA.clear();
		try {
			Path f = file();
			if (Files.exists(f)) {
				JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
				for (Map.Entry<String, JsonElement> e : o.entrySet()) {
					List<String> l = new ArrayList<>();
					e.getValue().getAsJsonArray().forEach(x -> l.add(x.getAsString()));
					DATA.put(e.getKey(), l);
				}
			}
		} catch (Exception ignored) {
		}
	}

	private static void save() {
		try {
			JsonObject o = new JsonObject();
			for (Map.Entry<String, List<String>> e : DATA.entrySet()) {
				JsonArray a = new JsonArray();
				e.getValue().forEach(a::add);
				o.add(e.getKey(), a);
			}
			Files.writeString(file(), o.toString());
		} catch (Exception ignored) {
		}
	}

	public static List<String> names() {
		return new ArrayList<>(DATA.keySet());
	}

	public static void remove(String name) {
		DATA.remove(name);
		save();
	}

	private static String slotName(int i) {
		if (i < 9) return "hotbar." + i;
		if (i < 36) return "inventory." + (i - 9);
		return switch (i) {
			case 36 -> "armor.feet";
			case 37 -> "armor.legs";
			case 38 -> "armor.chest";
			case 39 -> "armor.head";
			default -> "weapon.offhand";
		};
	}

	/** Speichert das aktuelle Inventar unter dem Namen. Gibt false zurueck, wenn nichts zu speichern war. */
	public static boolean saveCurrent(String name) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || name.isBlank()) return false;
		Inventory inv = mc.player.getInventory();
		List<String> list = new ArrayList<>();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack s = inv.getItem(i);
			if (s.isEmpty()) continue;
			String spec = StackUtil.spec(s);
			if (spec != null) list.add(slotName(i) + "\t" + spec);
		}
		DATA.put(name.trim(), list);
		save();
		return true;
	}

	/** Leert das Inventar und stellt den Stand per Befehlen wieder her. */
	public static void loadInto(String name) {
		List<String> list = DATA.get(name);
		if (list == null) return;
		CommandQueue.add("clear @s");
		for (String line : list) {
			int t = line.indexOf('\t');
			if (t < 0) continue;
			CommandQueue.add("item replace entity @s " + line.substring(0, t) + " with " + line.substring(t + 1));
		}
	}
}
