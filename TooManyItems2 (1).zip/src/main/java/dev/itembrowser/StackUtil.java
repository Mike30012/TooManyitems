package dev.itembrowser;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;

/** Hilfsfunktionen: Item -> Befehls-Text (id[komponenten] anzahl) und Text-JSON. */
public final class StackUtil {
	private static final String CODES = "0123456789abcdef";
	private static final String[] COLOR_NAMES = {"black", "dark_blue", "dark_green", "dark_aqua", "dark_red",
			"dark_purple", "gold", "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"};

	private StackUtil() {}

	private static CompoundTag encode(ItemStack s) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null || s.isEmpty()) return null;
		var ops = mc.level.registryAccess().createSerializationContext(NbtOps.INSTANCE);
		Tag t = ItemStack.CODEC.encodeStart(ops, s).result().orElse(null);
		return t instanceof CompoundTag c ? c : null;
	}

	/** Baut "id[komponenten] anzahl". over: Komponenten (ohne minecraft:), die ueberschrieben/hinzugefuegt werden. */
	public static String spec(ItemStack s, Map<String, String> over, int count) {
		String id = BuiltInRegistries.ITEM.getKey(s.getItem()).toString();
		Map<String, String> comps = new LinkedHashMap<>();
		CompoundTag ct = encode(s);
		if (ct != null) {
			CompoundTag cc = ct.getCompound("components");
			for (String k : cc.getAllKeys()) {
				comps.put(k, cc.get(k).toString());
			}
		}
		if (over != null) {
			for (Map.Entry<String, String> e : over.entrySet()) {
				comps.remove("minecraft:" + e.getKey());
				comps.put(e.getKey(), e.getValue());
			}
		}
		StringBuilder sb = new StringBuilder(id);
		if (!comps.isEmpty()) {
			sb.append('[');
			boolean first = true;
			for (Map.Entry<String, String> e : comps.entrySet()) {
				if (!first) sb.append(',');
				first = false;
				sb.append(e.getKey()).append('=').append(e.getValue());
			}
			sb.append(']');
		}
		return sb.append(' ').append(count).toString();
	}

	/** Vollstaendiger Text eines Stacks fuer Saves (mit Anzahl). */
	public static String spec(ItemStack s) {
		return encode(s) == null ? null : spec(s, null, s.getCount());
	}

	/** Text als SNBT-String in einfachen Anfuehrungszeichen. */
	public static String snbt(String s) {
		return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
	}

	private static String jsonEsc(String s) {
		return s.replace("\\", "\\\\").replace("\"", "\\\"");
	}

	/** Text mit &-Farbcodes (&c = rot usw.) als JSON-Text, nicht kursiv. */
	public static String json(String s) {
		StringBuilder sb = new StringBuilder("[{\"text\":\"\",\"italic\":false}");
		StringBuilder cur = new StringBuilder();
		String color = null;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '&' && i + 1 < s.length()) {
				int idx = CODES.indexOf(Character.toLowerCase(s.charAt(i + 1)));
				if (idx >= 0) {
					flush(sb, cur, color);
					color = COLOR_NAMES[idx];
					i++;
					continue;
				}
			}
			cur.append(c);
		}
		flush(sb, cur, color);
		return sb.append(']').toString();
	}

	private static void flush(StringBuilder sb, StringBuilder cur, String color) {
		if (cur.length() == 0) return;
		sb.append(",{\"text\":\"").append(jsonEsc(cur.toString())).append("\",\"italic\":false");
		if (color != null) sb.append(",\"color\":\"").append(color).append('"');
		sb.append('}');
		cur.setLength(0);
	}

	/** "ff0000, 00ff00" -> "I;16711680,65280" (Hex-Farben als Int-Array). */
	public static String colorArray(String text, int fallback) {
		StringBuilder sb = new StringBuilder("I;");
		boolean any = false;
		for (String p : text.split("[,; ]+")) {
			String h = p.trim().replace("#", "");
			if (h.isEmpty()) continue;
			try {
				int v = Integer.parseInt(h, 16) & 0xFFFFFF;
				if (any) sb.append(',');
				sb.append(v);
				any = true;
			} catch (NumberFormatException ignored) {
			}
		}
		if (!any && fallback >= 0) sb.append(fallback).append("");
		return sb.toString();
	}

	public static int parseHex(String text, int fallback) {
		try {
			return Integer.parseInt(text.trim().replace("#", ""), 16) & 0xFFFFFF;
		} catch (NumberFormatException e) {
			return fallback;
		}
	}
}
